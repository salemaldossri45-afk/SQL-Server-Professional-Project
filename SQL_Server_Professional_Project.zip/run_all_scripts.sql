-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: run_all_scripts.sql
-- الوصف: تنفيذ جميع سكريبتات المشروع بالترتيب الصحيح
-- ===================================================

-- تحذير: هذا الملف سيقوم بإنشاء قاعدة البيانات الكاملة
-- تأكد من أنك تريد المتابعة قبل التنفيذ

PRINT '=== بدء تنفيذ مشروع SQL Server احترافي ===';
PRINT 'تاريخ البدء: ' + CONVERT(NVARCHAR(20), GETDATE(), 120);
PRINT '';

-- ===================================================
-- 1. إنشاء قاعدة البيانات والمخططات
-- ===================================================

PRINT '1. إنشاء قاعدة البيانات والمخططات...';

-- إنشاء قاعدة البيانات
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'CompanyManagementDB')
BEGIN
    CREATE DATABASE CompanyManagementDB;
    PRINT 'تم إنشاء قاعدة البيانات CompanyManagementDB';
END
ELSE
BEGIN
    PRINT 'قاعدة البيانات CompanyManagementDB موجودة مسبقاً';
END

-- استخدام قاعدة البيانات
USE CompanyManagementDB;
GO

-- إنشاء المخططات
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'HR')
BEGIN
    CREATE SCHEMA HR;
    PRINT 'تم إنشاء مخطط HR';
END

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Projects')
BEGIN
    CREATE SCHEMA Projects;
    PRINT 'تم إنشاء مخطط Projects';
END

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Finance')
BEGIN
    CREATE SCHEMA Finance;
    PRINT 'تم إنشاء مخطط Finance';
END

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Security')
BEGIN
    CREATE SCHEMA Security;
    PRINT 'تم إنشاء مخطط Security';
END

PRINT 'تم الانتهاء من إنشاء قاعدة البيانات والمخططات';
PRINT '';

-- ===================================================
-- 2. إنشاء الجداول
-- ===================================================

PRINT '2. إنشاء الجداول...';

-- التحقق من عدم وجود الجداول مسبقاً
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Departments' AND schema_id = SCHEMA_ID('HR'))
BEGIN
    -- جدول الأقسام
    CREATE TABLE HR.Departments (
        DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
        DepartmentName NVARCHAR(100) NOT NULL UNIQUE,
        DepartmentCode NVARCHAR(10) NOT NULL UNIQUE,
        ManagerID INT NULL,
        Budget DECIMAL(15,2) DEFAULT 0,
        CreatedDate DATETIME2 DEFAULT GETDATE(),
        IsActive BIT DEFAULT 1
    );
    PRINT 'تم إنشاء جدول HR.Departments';
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Employees' AND schema_id = SCHEMA_ID('HR'))
BEGIN
    -- جدول الموظفين
    CREATE TABLE HR.Employees (
        EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
        FirstName NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        Email NVARCHAR(100) NOT NULL UNIQUE,
        Phone NVARCHAR(20),
        HireDate DATE NOT NULL,
        DepartmentID INT NOT NULL,
        Position NVARCHAR(100) NOT NULL,
        Salary DECIMAL(10,2) NOT NULL CHECK (Salary > 0),
        ManagerID INT NULL,
        IsActive BIT DEFAULT 1,
        CreatedDate DATETIME2 DEFAULT GETDATE(),
        ModifiedDate DATETIME2 DEFAULT GETDATE(),
        
        CONSTRAINT FK_Employees_Department 
            FOREIGN KEY (DepartmentID) REFERENCES HR.Departments(DepartmentID),
        CONSTRAINT FK_Employees_Manager 
            FOREIGN KEY (ManagerID) REFERENCES HR.Employees(EmployeeID)
    );
    PRINT 'تم إنشاء جدول HR.Employees';
END

-- إضافة المدير للقسم بعد إنشاء جدول الموظفين
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Departments_Manager')
BEGIN
    ALTER TABLE HR.Departments
    ADD CONSTRAINT FK_Departments_Manager 
        FOREIGN KEY (ManagerID) REFERENCES HR.Employees(EmployeeID);
    PRINT 'تم إضافة علاقة المدير للأقسام';
END

-- باقي الجداول...
-- (سيتم تضمين جميع الجداول هنا في التطبيق الفعلي)

PRINT 'تم الانتهاء من إنشاء الجداول الأساسية';
PRINT '';

-- ===================================================
-- 3. إدراج البيانات النموذجية
-- ===================================================

PRINT '3. إدراج البيانات النموذجية...';

-- التحقق من عدم وجود بيانات مسبقاً
IF NOT EXISTS (SELECT * FROM HR.Departments)
BEGIN
    -- إدراج الأقسام
    INSERT INTO HR.Departments (DepartmentName, DepartmentCode, Budget) VALUES
    ('تقنية المعلومات', 'IT', 500000.00),
    ('الموارد البشرية', 'HR', 200000.00),
    ('المالية', 'FIN', 300000.00),
    ('التسويق', 'MKT', 250000.00),
    ('المبيعات', 'SALES', 400000.00),
    ('العمليات', 'OPS', 350000.00);
    
    PRINT 'تم إدراج بيانات الأقسام';
END

IF NOT EXISTS (SELECT * FROM HR.Employees)
BEGIN
    -- إدراج الموظفين
    INSERT INTO HR.Employees (FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary) VALUES
    -- قسم تقنية المعلومات
    ('أحمد', 'محمد', 'ahmed.mohamed@company.com', '0501234567', '2020-01-15', 1, 'مدير تقنية المعلومات', 15000.00),
    ('فاطمة', 'علي', 'fatima.ali@company.com', '0501234568', '2020-03-10', 1, 'مطور برمجيات أول', 12000.00),
    ('محمد', 'أحمد', 'mohamed.ahmed@company.com', '0501234569', '2021-06-01', 1, 'مطور برمجيات', 9000.00),
    ('سارة', 'خالد', 'sara.khaled@company.com', '0501234570', '2021-09-15', 1, 'محلل أنظمة', 8500.00),
    ('عبدالله', 'سالم', 'abdullah.salem@company.com', '0501234571', '2022-02-01', 1, 'مطور واجهات', 7500.00),
    
    -- قسم الموارد البشرية
    ('نورا', 'عبدالرحمن', 'nora.abdulrahman@company.com', '0501234572', '2019-05-20', 2, 'مدير الموارد البشرية', 13000.00),
    ('خالد', 'محمود', 'khaled.mahmoud@company.com', '0501234573', '2020-08-10', 2, 'أخصائي توظيف', 7000.00),
    ('مريم', 'حسن', 'mariam.hassan@company.com', '0501234574', '2021-01-05', 2, 'أخصائي تدريب', 6500.00);
    
    PRINT 'تم إدراج بيانات الموظفين';
END

PRINT 'تم الانتهاء من إدراج البيانات النموذجية';
PRINT '';

-- ===================================================
-- 4. إنشاء الفهارس الأساسية
-- ===================================================

PRINT '4. إنشاء الفهارس الأساسية...';

-- فهارس جدول الموظفين
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Employees_DepartmentID')
BEGIN
    CREATE NONCLUSTERED INDEX IX_Employees_DepartmentID 
        ON HR.Employees (DepartmentID);
    PRINT 'تم إنشاء فهرس IX_Employees_DepartmentID';
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Employees_Email')
BEGIN
    CREATE NONCLUSTERED INDEX IX_Employees_Email 
        ON HR.Employees (Email);
    PRINT 'تم إنشاء فهرس IX_Employees_Email';
END

PRINT 'تم الانتهاء من إنشاء الفهارس الأساسية';
PRINT '';

-- ===================================================
-- 5. إنشاء المشاهد الأساسية
-- ===================================================

PRINT '5. إنشاء المشاهد الأساسية...';

-- مشهد تفاصيل الموظفين
IF NOT EXISTS (SELECT * FROM sys.views WHERE name = 'vw_EmployeeDetails' AND schema_id = SCHEMA_ID('HR'))
BEGIN
    EXEC('
    CREATE VIEW HR.vw_EmployeeDetails
    AS
    SELECT 
        e.EmployeeID,
        e.FirstName + '' '' + e.LastName AS FullName,
        e.Email,
        e.Phone,
        e.HireDate,
        e.Position,
        e.Salary,
        d.DepartmentName,
        d.DepartmentCode,
        m.FirstName + '' '' + m.LastName AS ManagerName,
        DATEDIFF(YEAR, e.HireDate, GETDATE()) AS YearsOfService,
        CASE 
            WHEN e.IsActive = 1 THEN ''نشط''
            ELSE ''غير نشط''
        END AS Status
    FROM HR.Employees e
    INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
    LEFT JOIN HR.Employees m ON e.ManagerID = m.EmployeeID
    WHERE e.IsActive = 1;
    ');
    PRINT 'تم إنشاء مشهد HR.vw_EmployeeDetails';
END

PRINT 'تم الانتهاء من إنشاء المشاهد الأساسية';
PRINT '';

-- ===================================================
-- 6. إنشاء إجراء مخزن أساسي
-- ===================================================

PRINT '6. إنشاء إجراء مخزن أساسي...';

-- إجراء لإضافة موظف جديد
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AddEmployee' AND schema_id = SCHEMA_ID('HR'))
BEGIN
    EXEC('
    CREATE PROCEDURE HR.sp_AddEmployee
        @FirstName NVARCHAR(50),
        @LastName NVARCHAR(50),
        @Email NVARCHAR(100),
        @Phone NVARCHAR(20) = NULL,
        @HireDate DATE,
        @DepartmentID INT,
        @Position NVARCHAR(100),
        @Salary DECIMAL(10,2),
        @ManagerID INT = NULL
    AS
    BEGIN
        SET NOCOUNT ON;
        
        BEGIN TRY
            BEGIN TRANSACTION;
            
            -- التحقق من وجود القسم
            IF NOT EXISTS (SELECT 1 FROM HR.Departments WHERE DepartmentID = @DepartmentID AND IsActive = 1)
            BEGIN
                RAISERROR(''القسم المحدد غير موجود أو غير نشط'', 16, 1);
                RETURN;
            END
            
            -- التحقق من عدم تكرار البريد الإلكتروني
            IF EXISTS (SELECT 1 FROM HR.Employees WHERE Email = @Email)
            BEGIN
                RAISERROR(''البريد الإلكتروني مستخدم مسبقاً'', 16, 1);
                RETURN;
            END
            
            -- إدراج الموظف الجديد
            INSERT INTO HR.Employees (FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary, ManagerID)
            VALUES (@FirstName, @LastName, @Email, @Phone, @HireDate, @DepartmentID, @Position, @Salary, @ManagerID);
            
            DECLARE @NewEmployeeID INT = SCOPE_IDENTITY();
            
            COMMIT TRANSACTION;
            
            SELECT @NewEmployeeID AS NewEmployeeID, ''تم إضافة الموظف بنجاح'' AS Message;
            
        END TRY
        BEGIN CATCH
            ROLLBACK TRANSACTION;
            
            DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
            RAISERROR(@ErrorMessage, 16, 1);
        END CATCH
    END;
    ');
    PRINT 'تم إنشاء إجراء HR.sp_AddEmployee';
END

PRINT 'تم الانتهاء من إنشاء الإجراءات المخزنة الأساسية';
PRINT '';

-- ===================================================
-- 7. إنشاء جدول التدقيق
-- ===================================================

PRINT '7. إنشاء جدول التدقيق...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AuditLog')
BEGIN
    CREATE TABLE dbo.AuditLog (
        AuditID INT IDENTITY(1,1) PRIMARY KEY,
        TableName NVARCHAR(100) NOT NULL,
        Operation NVARCHAR(10) NOT NULL,
        RecordID INT NOT NULL,
        OldValues NVARCHAR(MAX),
        NewValues NVARCHAR(MAX),
        ChangedBy NVARCHAR(100) DEFAULT SYSTEM_USER,
        ChangeDate DATETIME2 DEFAULT GETDATE()
    );
    PRINT 'تم إنشاء جدول dbo.AuditLog';
END

PRINT 'تم الانتهاء من إنشاء جدول التدقيق';
PRINT '';

-- ===================================================
-- 8. اختبار النظام
-- ===================================================

PRINT '8. اختبار النظام...';

-- اختبار إضافة موظف جديد
BEGIN TRY
    EXEC HR.sp_AddEmployee 
        @FirstName = 'علي',
        @LastName = 'الأحمد',
        @Email = 'ali.ahmad@company.com',
        @Phone = '0501234590',
        @HireDate = '2024-01-15',
        @DepartmentID = 1,
        @Position = 'مطور برمجيات متدرب',
        @Salary = 5000.00,
        @ManagerID = 2;
    
    PRINT 'تم اختبار إضافة موظف جديد بنجاح';
END TRY
BEGIN CATCH
    PRINT 'خطأ في اختبار إضافة موظف: ' + ERROR_MESSAGE();
END CATCH

-- اختبار المشهد
BEGIN TRY
    DECLARE @EmployeeCount INT;
    SELECT @EmployeeCount = COUNT(*) FROM HR.vw_EmployeeDetails;
    PRINT 'تم اختبار المشهد بنجاح - عدد الموظفين: ' + CAST(@EmployeeCount AS NVARCHAR(10));
END TRY
BEGIN CATCH
    PRINT 'خطأ في اختبار المشهد: ' + ERROR_MESSAGE();
END CATCH

PRINT 'تم الانتهاء من اختبار النظام';
PRINT '';

-- ===================================================
-- 9. إحصائيات النظام
-- ===================================================

PRINT '9. إحصائيات النظام:';

SELECT 'إجمالي الموظفين' AS Statistic, COUNT(*) AS Count FROM HR.Employees WHERE IsActive = 1
UNION ALL
SELECT 'إجمالي الأقسام', COUNT(*) FROM HR.Departments WHERE IsActive = 1
UNION ALL
SELECT 'إجمالي الجداول', COUNT(*) FROM sys.tables
UNION ALL
SELECT 'إجمالي المشاهد', COUNT(*) FROM sys.views
UNION ALL
SELECT 'إجمالي الإجراءات المخزنة', COUNT(*) FROM sys.procedures
UNION ALL
SELECT 'إجمالي الفهارس', COUNT(*) FROM sys.indexes WHERE name IS NOT NULL;

PRINT '';

-- ===================================================
-- 10. رسائل الإنهاء
-- ===================================================

PRINT '=== تم الانتهاء من تنفيذ مشروع SQL Server احترافي ===';
PRINT 'تاريخ الانتهاء: ' + CONVERT(NVARCHAR(20), GETDATE(), 120);
PRINT '';
PRINT 'ملاحظات مهمة:';
PRINT '1. تم إنشاء قاعدة البيانات CompanyManagementDB بنجاح';
PRINT '2. تم إنشاء الجداول والعلاقات الأساسية';
PRINT '3. تم إدراج بيانات نموذجية للاختبار';
PRINT '4. تم إنشاء فهارس ومشاهد وإجراءات أساسية';
PRINT '5. للحصول على الوظائف الكاملة، يرجى تنفيذ باقي الملفات حسب دليل التثبيت';
PRINT '';
PRINT 'الملفات المطلوبة للتنفيذ الكامل:';
PRINT '- 02_create_tables.sql (للجداول الكاملة)';
PRINT '- 03_create_indexes.sql (للفهارس المحسنة)';
PRINT '- 04_insert_sample_data.sql (للبيانات الكاملة)';
PRINT '- 05_create_views.sql (للمشاهد الكاملة)';
PRINT '- 06_create_stored_procedures.sql (للإجراءات الكاملة)';
PRINT '- 07_create_functions.sql (للدوال)';
PRINT '- 08_create_triggers.sql (للمشغلات)';
PRINT '- 11_performance_optimization.sql (لتحسين الأداء)';
PRINT '- 12_backup_and_security.sql (للأمان والنسخ الاحتياطي)';
PRINT '';
PRINT 'شكراً لاستخدام مشروع SQL Server احترافي!';

