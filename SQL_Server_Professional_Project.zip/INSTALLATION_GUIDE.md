# دليل التثبيت - مشروع SQL Server احترافي

## المتطلبات الأساسية

### متطلبات النظام
- **نظام التشغيل**: Windows Server 2016+ أو Windows 10+
- **SQL Server**: إصدار 2016 أو أحدث
- **الذاكرة**: 4 جيجابايت كحد أدنى، 8 جيجابايت مُوصى به
- **مساحة التخزين**: 10 جيجابايت كحد أدنى للبيانات والنسخ الاحتياطية
- **الشبكة**: اتصال بالشبكة للوصول عن بُعد (اختياري)

### البرامج المطلوبة
- **SQL Server Management Studio (SSMS)** - أحدث إصدار
- **SQL Server Database Engine**
- **SQL Server Agent** (للمهام المجدولة)

### الصلاحيات المطلوبة
- صلاحيات **sysadmin** على خادم SQL Server
- صلاحيات إنشاء قواعد البيانات
- صلاحيات إنشاء مستخدمين وأدوار

## خطوات التثبيت

### الخطوة 1: تحضير البيئة

#### 1.1 إنشاء مجلدات النسخ الاحتياطي
```cmd
mkdir C:\\Backup
mkdir C:\\Audit
```

#### 1.2 تعيين صلاحيات المجلدات
تأكد من أن حساب خدمة SQL Server له صلاحيات الكتابة في مجلدات النسخ الاحتياطي.

### الخطوة 2: إنشاء قاعدة البيانات

#### 2.1 تنفيذ ملف إنشاء قاعدة البيانات
```sql
-- افتح SQL Server Management Studio
-- اتصل بخادم SQL Server
-- افتح ملف 01_create_database.sql
-- نفذ الملف بالكامل
```

**الملف**: `01_create_database.sql`
```sql
-- سيتم إنشاء:
-- - قاعدة البيانات CompanyManagementDB
-- - المخططات: HR, Projects, Finance
```

#### 2.2 التحقق من إنشاء قاعدة البيانات
```sql
USE CompanyManagementDB;
SELECT name FROM sys.schemas WHERE name IN ('HR', 'Projects', 'Finance');
```

### الخطوة 3: إنشاء الجداول والعلاقات

#### 3.1 تنفيذ ملف إنشاء الجداول
```sql
-- افتح ملف 02_create_tables.sql
-- تأكد من أنك متصل بقاعدة البيانات CompanyManagementDB
-- نفذ الملف بالكامل
```

**الجداول التي سيتم إنشاؤها**:
- HR.Departments
- HR.Employees  
- HR.Attendance
- Projects.Projects
- Projects.EmployeeProjects
- Projects.Tasks
- Finance.SalaryHistory

#### 3.2 التحقق من إنشاء الجداول
```sql
SELECT 
    SCHEMA_NAME(schema_id) AS SchemaName,
    name AS TableName
FROM sys.tables
ORDER BY SchemaName, TableName;
```

### الخطوة 4: إنشاء الفهارس

#### 4.1 تنفيذ ملف إنشاء الفهارس
```sql
-- افتح ملف 03_create_indexes.sql
-- نفذ الملف بالكامل
```

#### 4.2 التحقق من إنشاء الفهارس
```sql
SELECT 
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS IndexName,
    type_desc AS IndexType
FROM sys.indexes
WHERE object_id IN (
    SELECT object_id FROM sys.tables 
    WHERE schema_id IN (
        SELECT schema_id FROM sys.schemas 
        WHERE name IN ('HR', 'Projects', 'Finance')
    )
)
ORDER BY SchemaName, TableName, IndexName;
```

### الخطوة 5: إدراج البيانات النموذجية

#### 5.1 تنفيذ ملف البيانات النموذجية
```sql
-- افتح ملف 04_insert_sample_data.sql
-- نفذ الملف بالكامل
```

#### 5.2 التحقق من إدراج البيانات
```sql
-- التحقق من عدد السجلات في كل جدول
SELECT 'Departments' AS TableName, COUNT(*) AS RecordCount FROM HR.Departments
UNION ALL
SELECT 'Employees', COUNT(*) FROM HR.Employees
UNION ALL
SELECT 'Projects', COUNT(*) FROM Projects.Projects
UNION ALL
SELECT 'Tasks', COUNT(*) FROM Projects.Tasks
UNION ALL
SELECT 'Attendance', COUNT(*) FROM HR.Attendance;
```

### الخطوة 6: إنشاء المشاهد (Views)

#### 6.1 تنفيذ ملف المشاهد
```sql
-- افتح ملف 05_create_views.sql
-- نفذ الملف بالكامل
```

#### 6.2 التحقق من إنشاء المشاهد
```sql
SELECT 
    SCHEMA_NAME(schema_id) AS SchemaName,
    name AS ViewName
FROM sys.views
WHERE schema_id IN (
    SELECT schema_id FROM sys.schemas 
    WHERE name IN ('HR', 'Projects', 'Finance')
)
ORDER BY SchemaName, ViewName;
```

### الخطوة 7: إنشاء الإجراءات المخزنة

#### 7.1 تنفيذ ملف الإجراءات المخزنة
```sql
-- افتح ملف 06_create_stored_procedures.sql
-- نفذ الملف بالكامل
```

#### 7.2 التحقق من إنشاء الإجراءات
```sql
SELECT 
    SCHEMA_NAME(schema_id) AS SchemaName,
    name AS ProcedureName
FROM sys.procedures
WHERE schema_id IN (
    SELECT schema_id FROM sys.schemas 
    WHERE name IN ('HR', 'Projects', 'Finance')
)
ORDER BY SchemaName, ProcedureName;
```

### الخطوة 8: إنشاء الدوال

#### 8.1 تنفيذ ملف الدوال
```sql
-- افتح ملف 07_create_functions.sql
-- نفذ الملف بالكامل
```

#### 8.2 التحقق من إنشاء الدوال
```sql
SELECT 
    SCHEMA_NAME(schema_id) AS SchemaName,
    name AS FunctionName,
    type_desc AS FunctionType
FROM sys.objects
WHERE type IN ('FN', 'IF', 'TF')
    AND schema_id IN (
        SELECT schema_id FROM sys.schemas 
        WHERE name IN ('HR', 'Projects', 'Finance')
    )
ORDER BY SchemaName, FunctionName;
```

### الخطوة 9: إنشاء المشغلات (Triggers)

#### 9.1 تنفيذ ملف المشغلات
```sql
-- افتح ملف 08_create_triggers.sql
-- نفذ الملف بالكامل
```

#### 9.2 التحقق من إنشاء المشغلات
```sql
SELECT 
    OBJECT_SCHEMA_NAME(parent_id) AS SchemaName,
    OBJECT_NAME(parent_id) AS TableName,
    name AS TriggerName,
    type_desc AS TriggerType
FROM sys.triggers
WHERE parent_id IN (
    SELECT object_id FROM sys.tables 
    WHERE schema_id IN (
        SELECT schema_id FROM sys.schemas 
        WHERE name IN ('HR', 'Projects', 'Finance')
    )
)
ORDER BY SchemaName, TableName, TriggerName;
```

### الخطوة 10: تحسين الأداء

#### 10.1 تنفيذ ملف تحسين الأداء
```sql
-- افتح ملف 11_performance_optimization.sql
-- نفذ الملف بالكامل
```

#### 10.2 التحقق من تحسينات الأداء
```sql
-- التحقق من الفهارس الإضافية
SELECT 
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS IndexName
FROM sys.indexes
WHERE name LIKE 'IX_%Optimized%'
ORDER BY SchemaName, TableName;
```

### الخطوة 11: إعداد الأمان والنسخ الاحتياطي

#### 11.1 إنشاء المستخدمين على مستوى الخادم
```sql
-- يجب تنفيذ هذا على قاعدة البيانات master
USE master;
GO

CREATE LOGIN hr_manager_login WITH PASSWORD = 'HRManager@2024!';
CREATE LOGIN project_manager_login WITH PASSWORD = 'ProjectMgr@2024!';
CREATE LOGIN finance_manager_login WITH PASSWORD = 'FinanceMgr@2024!';
CREATE LOGIN readonly_user_login WITH PASSWORD = 'ReadOnly@2024!';
```

#### 11.2 تنفيذ ملف الأمان والنسخ الاحتياطي
```sql
-- العودة إلى قاعدة البيانات الرئيسية
USE CompanyManagementDB;
GO

-- افتح ملف 12_backup_and_security.sql
-- نفذ الملف بالكامل (تجاهل أجزاء إنشاء المستخدمين إذا تم تنفيذها مسبقاً)
```

#### 11.3 التحقق من إعداد الأمان
```sql
-- التحقق من الأدوار
SELECT name AS RoleName FROM sys.database_principals WHERE type = 'R' AND name NOT IN ('public', 'db_owner', 'db_accessadmin', 'db_securityadmin', 'db_ddladmin', 'db_datareader', 'db_datawriter', 'db_denydatareader', 'db_denydatawriter');

-- التحقق من المستخدمين
SELECT name AS UserName FROM sys.database_principals WHERE type = 'S' AND name NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys');
```

### الخطوة 12: اختبار النظام

#### 12.1 تنفيذ اختبارات شاملة
```sql
-- افتح ملف 10_test_procedures.sql
-- نفذ الملف بالكامل
```

#### 12.2 تنفيذ الاستعلامات النموذجية
```sql
-- افتح ملف 09_sample_queries.sql
-- نفذ أجزاء مختلفة لاختبار الوظائف
```

## التحقق من التثبيت الناجح

### اختبار شامل للنظام
```sql
-- 1. التحقق من قاعدة البيانات
SELECT name FROM sys.databases WHERE name = 'CompanyManagementDB';

-- 2. التحقق من الجداول
SELECT COUNT(*) AS TableCount FROM sys.tables;

-- 3. التحقق من البيانات
SELECT 
    (SELECT COUNT(*) FROM HR.Employees) AS EmployeeCount,
    (SELECT COUNT(*) FROM HR.Departments) AS DepartmentCount,
    (SELECT COUNT(*) FROM Projects.Projects) AS ProjectCount;

-- 4. اختبار إجراء مخزن
EXEC HR.sp_GetEmployeePerformanceReport @EmployeeID = 1;

-- 5. اختبار مشهد
SELECT TOP 5 * FROM HR.vw_EmployeeDetails;
```

## إعداد المهام المجدولة

### 1. النسخ الاحتياطي التلقائي
```sql
-- إنشاء مهمة للنسخ الاحتياطي الكامل (أسبوعياً)
USE msdb;
GO

EXEC dbo.sp_add_job
    @job_name = N'CompanyDB Full Backup Weekly';

EXEC dbo.sp_add_jobstep
    @job_name = N'CompanyDB Full Backup Weekly',
    @step_name = N'Full Backup',
    @command = N'EXEC CompanyManagementDB.dbo.sp_FullBackup',
    @database_name = N'CompanyManagementDB';

EXEC dbo.sp_add_schedule
    @schedule_name = N'Weekly Sunday 2AM',
    @freq_type = 8, -- Weekly
    @freq_interval = 1, -- Sunday
    @freq_recurrence_factor = 1,
    @active_start_time = 020000; -- 2:00 AM

EXEC dbo.sp_attach_schedule
    @job_name = N'CompanyDB Full Backup Weekly',
    @schedule_name = N'Weekly Sunday 2AM';

EXEC dbo.sp_add_jobserver
    @job_name = N'CompanyDB Full Backup Weekly';
```

### 2. صيانة الفهارس
```sql
-- إنشاء مهمة لصيانة الفهارس (أسبوعياً)
EXEC dbo.sp_add_job
    @job_name = N'CompanyDB Index Maintenance';

EXEC dbo.sp_add_jobstep
    @job_name = N'CompanyDB Index Maintenance',
    @step_name = N'Rebuild and Reorganize Indexes',
    @command = N'EXEC CompanyManagementDB.dbo.sp_MaintenanceIndexes',
    @database_name = N'CompanyManagementDB';

EXEC dbo.sp_add_schedule
    @schedule_name = N'Weekly Saturday 1AM',
    @freq_type = 8, -- Weekly
    @freq_interval = 64, -- Saturday
    @freq_recurrence_factor = 1,
    @active_start_time = 010000; -- 1:00 AM

EXEC dbo.sp_attach_schedule
    @job_name = N'CompanyDB Index Maintenance',
    @schedule_name = N'Weekly Saturday 1AM';

EXEC dbo.sp_add_jobserver
    @job_name = N'CompanyDB Index Maintenance';
```

## استكشاف الأخطاء وإصلاحها

### مشاكل شائعة وحلولها

#### 1. خطأ في إنشاء قاعدة البيانات
```sql
-- التحقق من وجود قاعدة البيانات
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'CompanyManagementDB')
    DROP DATABASE CompanyManagementDB;
```

#### 2. خطأ في الصلاحيات
```sql
-- التحقق من الصلاحيات الحالية
SELECT 
    dp.name AS principal_name,
    dp.type_desc AS principal_type,
    o.name AS object_name,
    p.permission_name,
    p.state_desc AS permission_state
FROM sys.database_permissions p
LEFT JOIN sys.objects o ON p.major_id = o.object_id
LEFT JOIN sys.database_principals dp ON p.grantee_principal_id = dp.principal_id;
```

#### 3. مشاكل في الأداء
```sql
-- التحقق من حالة الفهارس
SELECT 
    OBJECT_NAME(ips.object_id) AS TableName,
    i.name AS IndexName,
    ips.avg_fragmentation_in_percent
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ips
INNER JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id
WHERE ips.avg_fragmentation_in_percent > 10
ORDER BY ips.avg_fragmentation_in_percent DESC;
```

## الخطوات التالية

بعد التثبيت الناجح:

1. **تخصيص البيانات**: استبدل البيانات النموذجية ببيانات شركتك الفعلية
2. **إعداد النسخ الاحتياطي**: تأكد من جدولة النسخ الاحتياطية المنتظمة
3. **مراقبة الأداء**: راقب أداء النظام وقم بالتحسينات حسب الحاجة
4. **تدريب المستخدمين**: درب المستخدمين على استخدام النظام
5. **التوثيق**: وثق أي تخصيصات أو تغييرات إضافية

## الدعم

للحصول على الدعم أو الإبلاغ عن مشاكل، يرجى مراجعة:
- ملف README.md للتوثيق الشامل
- ملفات SQL للتفاصيل التقنية
- سجلات النظام لاستكشاف الأخطاء

---

**ملاحظة مهمة**: تأكد من تغيير جميع كلمات المرور الافتراضية قبل النشر في بيئة الإنتاج!

