# مشروع SQL Server احترافي - نظام إدارة الشركة

## نظرة عامة على المشروع

هذا مشروع SQL Server احترافي شامل لنظام إدارة الشركة يتضمن إدارة الموظفين، المشاريع، والعمليات المالية. تم تصميم المشروع باستخدام أفضل الممارسات في تطوير قواعد البيانات وتحسين الأداء والأمان.

## هيكل المشروع

### الملفات الرئيسية

1. **01_create_database.sql** - إنشاء قاعدة البيانات والمخططات (Schemas)
2. **02_create_tables.sql** - إنشاء جميع الجداول والعلاقات
3. **03_create_indexes.sql** - إنشاء الفهارس لتحسين الأداء
4. **04_insert_sample_data.sql** - إدراج بيانات وهمية للاختبار
5. **05_create_views.sql** - إنشاء المشاهد (Views) لتبسيط الاستعلامات
6. **06_create_stored_procedures.sql** - إنشاء الإجراءات المخزنة
7. **07_create_functions.sql** - إنشاء الدوال المخصصة
8. **08_create_triggers.sql** - إنشاء المشغلات للتحقق من صحة البيانات
9. **09_sample_queries.sql** - استعلامات نموذجية لاستخدام قاعدة البيانات
10. **10_test_procedures.sql** - اختبار الإجراءات المخزنة والدوال
11. **11_performance_optimization.sql** - تحسين أداء قاعدة البيانات
12. **12_backup_and_security.sql** - إعداد النسخ الاحتياطي والأمان

### الملفات التوثيقية

- **README.md** - هذا الملف (التوثيق الرئيسي)
- **sql_server_project_plan.md** - خطة المشروع التفصيلية
- **dashboard_design_analysis.md** - تحليل تصميم لوحة المعلومات

## هيكل قاعدة البيانات

### المخططات (Schemas)

- **HR** - الموارد البشرية
- **Projects** - إدارة المشاريع
- **Finance** - الشؤون المالية
- **Security** - الأمان والحماية

### الجداول الرئيسية

#### مخطط الموارد البشرية (HR)
- **Departments** - الأقسام
- **Employees** - الموظفين
- **Attendance** - سجل الحضور

#### مخطط المشاريع (Projects)
- **Projects** - المشاريع
- **EmployeeProjects** - ربط الموظفين بالمشاريع
- **Tasks** - المهام

#### مخطط المالية (Finance)
- **SalaryHistory** - تاريخ الرواتب

## الميزات الرئيسية

### 1. إدارة الموظفين
- تسجيل بيانات الموظفين الكاملة
- تتبع الهيكل التنظيمي
- إدارة الحضور والغياب
- تتبع تاريخ الرواتب

### 2. إدارة المشاريع
- إنشاء وإدارة المشاريع
- تعيين فرق العمل
- تتبع المهام والتقدم
- حساب التكاليف والميزانيات

### 3. التقارير والتحليلات
- تقارير أداء الموظفين
- إحصائيات الأقسام
- تحليل المشاريع
- تقارير الحضور

### 4. الأمان والحماية
- أدوار مستخدمين متعددة
- تشفير البيانات الحساسة
- تسجيل العمليات (Audit Log)
- سياسات الأمان على مستوى الصفوف

### 5. تحسين الأداء
- فهارس محسنة
- مشاهد مفهرسة
- إجراءات صيانة دورية
- مراقبة الأداء

## متطلبات التشغيل

- **SQL Server 2016** أو أحدث
- **SQL Server Management Studio (SSMS)**
- صلاحيات إنشاء قواعد البيانات
- مساحة تخزين كافية للبيانات والنسخ الاحتياطية

## تعليمات التثبيت

### 1. إنشاء قاعدة البيانات
```sql
-- تنفيذ الملفات بالترتيب التالي:
-- 1. 01_create_database.sql
-- 2. 02_create_tables.sql
-- 3. 03_create_indexes.sql
```

### 2. إدراج البيانات النموذجية
```sql
-- 4. 04_insert_sample_data.sql
```

### 3. إنشاء الكائنات المتقدمة
```sql
-- 5. 05_create_views.sql
-- 6. 06_create_stored_procedures.sql
-- 7. 07_create_functions.sql
-- 8. 08_create_triggers.sql
```

### 4. تحسين الأداء والأمان
```sql
-- 9. 11_performance_optimization.sql
-- 10. 12_backup_and_security.sql
```

### 5. الاختبار
```sql
-- 11. 10_test_procedures.sql
-- 12. 09_sample_queries.sql
```

## الاستخدام

### إضافة موظف جديد
```sql
EXEC HR.sp_AddEmployee 
    @FirstName = 'أحمد',
    @LastName = 'محمد',
    @Email = 'ahmed.mohamed@company.com',
    @Phone = '0501234567',
    @HireDate = '2024-01-15',
    @DepartmentID = 1,
    @Position = 'مطور برمجيات',
    @Salary = 8000.00,
    @ManagerID = 2;
```

### إنشاء مشروع جديد
```sql
EXEC Projects.sp_AddProject 
    @ProjectName = 'نظام إدارة العملاء',
    @ProjectCode = 'CRM2024',
    @Description = 'تطوير نظام CRM متطور',
    @StartDate = '2024-01-01',
    @EndDate = '2024-06-30',
    @Budget = 200000.00,
    @ProjectManagerID = 1;
```

### تسجيل الحضور
```sql
EXEC HR.sp_RecordAttendance 
    @EmployeeID = 1,
    @CheckInTime = '08:30:00',
    @CheckOutTime = '17:30:00',
    @Status = 'Present';
```

## التقارير المتاحة

### 1. تقرير أداء الموظف
```sql
EXEC HR.sp_GetEmployeePerformanceReport 
    @EmployeeID = 1,
    @StartDate = '2024-01-01',
    @EndDate = '2024-01-31';
```

### 2. إحصائيات الأقسام
```sql
SELECT * FROM HR.vw_DepartmentStatistics;
```

### 3. تفاصيل المشاريع
```sql
SELECT * FROM Projects.vw_ProjectDetails;
```

## الصيانة الدورية

### النسخ الاحتياطي
```sql
-- نسخة احتياطية كاملة
EXEC dbo.sp_FullBackup;

-- نسخة احتياطية تفاضلية
EXEC dbo.sp_DifferentialBackup;

-- نسخة احتياطية لسجل المعاملات
EXEC dbo.sp_LogBackup;
```

### صيانة الفهارس
```sql
EXEC dbo.sp_MaintenanceIndexes;
```

### تنظيف البيانات القديمة
```sql
EXEC dbo.sp_CleanupOldData @DaysToKeep = 90;
```

## الأمان

### الأدوار المتاحة
- **HR_Manager** - مدير الموارد البشرية
- **HR_Employee** - موظف الموارد البشرية
- **Project_Manager** - مدير المشاريع
- **Project_Member** - عضو فريق المشروع
- **Finance_Manager** - مدير المالية
- **Finance_Employee** - موظف المالية
- **Executive** - الإدارة العليا
- **ReadOnly_User** - مستخدم قراءة فقط

### إجراءات الطوارئ
```sql
-- تعطيل الوصول في حالة الطوارئ
EXEC Security.sp_EmergencyLockdown @Reason = 'Security breach detected';

-- استعادة الوصول
EXEC Security.sp_RestoreAccess;
```

## مراقبة الأداء

### تحليل أداء قاعدة البيانات
```sql
EXEC dbo.sp_AnalyzeDatabasePerformance;
```

### مراقبة الوصول
```sql
SELECT * FROM Security.vw_AccessMonitoring;
```

## الدعم والصيانة

### سجل التدقيق
جميع العمليات المهمة يتم تسجيلها في جدول `dbo.AuditLog` لأغراض التدقيق والمراجعة.

### مراقبة الأداء
يتم تسجيل أداء الاستعلامات في جدول `dbo.PerformanceMonitoring` لتحليل وتحسين الأداء.

### النسخ الاحتياطي التلقائي
يُنصح بجدولة النسخ الاحتياطية كما يلي:
- **نسخة كاملة**: أسبوعياً
- **نسخة تفاضلية**: يومياً
- **نسخة سجل المعاملات**: كل 15 دقيقة

## الملاحظات المهمة

1. **الأمان**: تأكد من تغيير كلمات المرور الافتراضية قبل النشر في بيئة الإنتاج
2. **الأداء**: راقب أداء الاستعلامات بانتظام وقم بتحديث الإحصائيات
3. **النسخ الاحتياطي**: تأكد من اختبار استعادة النسخ الاحتياطية بانتظام
4. **التحديثات**: قم بتحديث SQL Server بانتظام للحصول على أحدث التحسينات الأمنية

## المطور

تم تطوير هذا المشروع باستخدام أفضل الممارسات في تطوير قواعد البيانات SQL Server، مع التركيز على الأداء والأمان وسهولة الصيانة.

---

**تاريخ الإنشاء**: يناير 2024  
**الإصدار**: 1.0  
**متوافق مع**: SQL Server 2016+

