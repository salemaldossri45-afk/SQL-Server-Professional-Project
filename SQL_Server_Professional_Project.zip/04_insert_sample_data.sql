-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 04_insert_sample_data.sql
-- الوصف: إدراج بيانات وهمية للاختبار
-- ===================================================

USE CompanyManagementDB;
GO

-- إدراج الأقسام
INSERT INTO HR.Departments (DepartmentName, DepartmentCode, Budget) VALUES
('تقنية المعلومات', 'IT', 500000.00),
('الموارد البشرية', 'HR', 200000.00),
('المالية', 'FIN', 300000.00),
('التسويق', 'MKT', 250000.00),
('المبيعات', 'SALES', 400000.00),
('العمليات', 'OPS', 350000.00);

-- إدراج الموظفين
INSERT INTO HR.Employees (FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary) VALUES
-- قسم تقنية المعلومات
('أحمد', 'محمد', 'ahmed.mohamed@company.com', '0501234567', '2020-01-15', 1, 'مدير تقنية المعلومات', 15000.00),
('فاطمة', 'علي', 'fatima.ali@company.com', '0501234568', '2020-03-10', 1, 'مطور برمجيات أول', 12000.00),
('محمد', 'أحمد', 'mohamed.ahmed@company.com', '0501234569', '2021-06-01', 1, 'مطور برمجيات', 9000.00),
('سارة', 'خالد', 'sara.khaled@company.com', '0501234570', '2021-09-15', 1, 'محلل أنظمة', 8500.00),
('عبدالله', 'سالم', 'abdullah.salem@company.com', '0501234571', '2022-02-01', 1, 'مطور واجهات', 7500.00),

-- قسم الموارد البشرية
('نورا', 'عبدالرحمن', 'nora.abdulrahman@company.com', '0501234572', '2019-05-20', 2, 'مدير الموارد البشرية', 13000.00),
('خالد', 'محمود', 'khaled.mahmoud@company.com', '0501234573', '2020-08-10', 2, 'أخصائي توظيف', 7000.00),
('مريم', 'حسن', 'mariam.hassan@company.com', '0501234574', '2021-01-05', 2, 'أخصائي تدريب', 6500.00),

-- قسم المالية
('عمر', 'يوسف', 'omar.youssef@company.com', '0501234575', '2018-11-12', 3, 'مدير مالي', 14000.00),
('ليلى', 'إبراهيم', 'layla.ibrahim@company.com', '0501234576', '2020-04-18', 3, 'محاسب أول', 8000.00),
('حسام', 'عثمان', 'hussam.othman@company.com', '0501234577', '2021-07-22', 3, 'محاسب', 6000.00),

-- قسم التسويق
('رنا', 'الأحمد', 'rana.alahmad@company.com', '0501234578', '2019-09-30', 4, 'مدير التسويق', 12000.00),
('طارق', 'النجار', 'tarek.najjar@company.com', '0501234579', '2020-12-05', 4, 'أخصائي تسويق رقمي', 7500.00),
('دينا', 'الشامي', 'dina.shami@company.com', '0501234580', '2021-03-20', 4, 'مصمم جرافيك', 6500.00),

-- قسم المبيعات
('يوسف', 'الخطيب', 'youssef.khatib@company.com', '0501234581', '2019-02-14', 5, 'مدير المبيعات', 13500.00),
('هند', 'العلي', 'hind.ali@company.com', '0501234582', '2020-06-08', 5, 'مندوب مبيعات أول', 8500.00),
('سامي', 'الحمود', 'sami.hamoud@company.com', '0501234583', '2021-10-12', 5, 'مندوب مبيعات', 7000.00),

-- قسم العمليات
('لينا', 'القاسم', 'lina.qasem@company.com', '0501234584', '2018-07-25', 6, 'مدير العمليات', 13000.00),
('ماجد', 'الزهراني', 'majed.zahrani@company.com', '0501234585', '2020-11-30', 6, 'منسق عمليات', 7500.00),
('ريم', 'الدوسري', 'reem.dosari@company.com', '0501234586', '2021-05-16', 6, 'أخصائي جودة', 6800.00);

-- تحديث مديري الأقسام
UPDATE HR.Departments SET ManagerID = 1 WHERE DepartmentID = 1; -- IT
UPDATE HR.Departments SET ManagerID = 6 WHERE DepartmentID = 2; -- HR
UPDATE HR.Departments SET ManagerID = 9 WHERE DepartmentID = 3; -- Finance
UPDATE HR.Departments SET ManagerID = 12 WHERE DepartmentID = 4; -- Marketing
UPDATE HR.Departments SET ManagerID = 15 WHERE DepartmentID = 5; -- Sales
UPDATE HR.Departments SET ManagerID = 18 WHERE DepartmentID = 6; -- Operations

-- تحديث المديرين المباشرين للموظفين
UPDATE HR.Employees SET ManagerID = 1 WHERE EmployeeID IN (2, 3, 4, 5); -- IT team
UPDATE HR.Employees SET ManagerID = 6 WHERE EmployeeID IN (7, 8); -- HR team
UPDATE HR.Employees SET ManagerID = 9 WHERE EmployeeID IN (10, 11); -- Finance team
UPDATE HR.Employees SET ManagerID = 12 WHERE EmployeeID IN (13, 14); -- Marketing team
UPDATE HR.Employees SET ManagerID = 15 WHERE EmployeeID IN (16, 17); -- Sales team
UPDATE HR.Employees SET ManagerID = 18 WHERE EmployeeID IN (19, 20); -- Operations team

-- إدراج المشاريع
INSERT INTO Projects.Projects (ProjectName, ProjectCode, Description, StartDate, EndDate, Budget, Status, ProjectManagerID) VALUES
('نظام إدارة العملاء الجديد', 'CRM2024', 'تطوير نظام CRM متطور لإدارة العملاء', '2024-01-01', '2024-06-30', 200000.00, 'In Progress', 1),
('تحديث الموقع الإلكتروني', 'WEB2024', 'إعادة تصميم وتطوير الموقع الإلكتروني للشركة', '2024-02-15', '2024-05-15', 80000.00, 'In Progress', 2),
('نظام إدارة الموارد البشرية', 'HRMS2024', 'تطوير نظام شامل لإدارة الموارد البشرية', '2024-03-01', '2024-08-31', 150000.00, 'Planning', 6),
('حملة التسويق الرقمي', 'DIGITAL2024', 'حملة تسويقية شاملة عبر المنصات الرقمية', '2024-01-15', '2024-12-31', 100000.00, 'In Progress', 12),
('تحسين العمليات التشغيلية', 'OPS2024', 'مشروع لتحسين وأتمتة العمليات التشغيلية', '2024-02-01', '2024-07-31', 120000.00, 'Planning', 18);

-- إدراج ربط الموظفين بالمشاريع
INSERT INTO Projects.EmployeeProjects (EmployeeID, ProjectID, Role, HoursAllocated) VALUES
-- مشروع CRM
(1, 1, 'مدير المشروع', 20.0),
(2, 1, 'مطور رئيسي', 40.0),
(3, 1, 'مطور', 40.0),
(4, 1, 'محلل أنظمة', 30.0),

-- مشروع الموقع الإلكتروني
(2, 2, 'مدير المشروع', 25.0),
(5, 2, 'مطور واجهات', 40.0),
(14, 2, 'مصمم جرافيك', 20.0),

-- مشروع HRMS
(6, 3, 'مدير المشروع', 20.0),
(1, 3, 'استشاري تقني', 10.0),
(3, 3, 'مطور', 35.0),

-- مشروع التسويق الرقمي
(12, 4, 'مدير المشروع', 30.0),
(13, 4, 'أخصائي تسويق رقمي', 40.0),
(14, 4, 'مصمم جرافيك', 25.0),

-- مشروع تحسين العمليات
(18, 5, 'مدير المشروع', 25.0),
(19, 5, 'منسق عمليات', 35.0),
(20, 5, 'أخصائي جودة', 30.0);

-- إدراج بيانات الحضور (عينة لأسبوع واحد)
DECLARE @StartDate DATE = '2024-01-01';
DECLARE @EmployeeID INT = 1;

WHILE @EmployeeID <= 20
BEGIN
    DECLARE @CurrentDate DATE = @StartDate;
    DECLARE @DayCount INT = 0;
    
    WHILE @DayCount < 7
    BEGIN
        IF DATEPART(WEEKDAY, @CurrentDate) NOT IN (1, 7) -- ليس عطلة نهاية أسبوع
        BEGIN
            INSERT INTO HR.Attendance (EmployeeID, AttendanceDate, CheckInTime, CheckOutTime, Status)
            VALUES (
                @EmployeeID, 
                @CurrentDate, 
                DATEADD(MINUTE, ABS(CHECKSUM(NEWID())) % 60, '08:00:00'), -- وقت دخول عشوائي بين 8:00-9:00
                DATEADD(MINUTE, ABS(CHECKSUM(NEWID())) % 60 + 480, '17:00:00'), -- وقت خروج عشوائي بين 17:00-18:00
                'Present'
            );
        END
        
        SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
        SET @DayCount = @DayCount + 1;
    END
    
    SET @EmployeeID = @EmployeeID + 1;
END

-- إدراج بعض المهام
INSERT INTO Projects.Tasks (ProjectID, TaskName, Description, AssignedTo, Priority, Status, EstimatedHours, StartDate, DueDate) VALUES
(1, 'تحليل المتطلبات', 'تحليل وتوثيق متطلبات نظام CRM', 4, 'High', 'Completed', 40.0, '2024-01-01', '2024-01-15'),
(1, 'تصميم قاعدة البيانات', 'تصميم هيكل قاعدة البيانات', 2, 'High', 'Completed', 30.0, '2024-01-16', '2024-01-30'),
(1, 'تطوير واجهة المستخدم', 'تطوير واجهات المستخدم الرئيسية', 3, 'Medium', 'In Progress', 60.0, '2024-02-01', '2024-03-15'),
(1, 'تطوير API', 'تطوير واجهات برمجة التطبيقات', 2, 'High', 'In Progress', 50.0, '2024-02-15', '2024-03-30'),

(2, 'تصميم الموقع', 'تصميم واجهات الموقع الجديد', 14, 'Medium', 'Completed', 25.0, '2024-02-15', '2024-03-01'),
(2, 'تطوير الواجهة الأمامية', 'تطوير الواجهة الأمامية للموقع', 5, 'High', 'In Progress', 45.0, '2024-03-01', '2024-04-15'),

(4, 'إعداد الحملة الإعلانية', 'تحضير المحتوى والإعلانات', 13, 'Medium', 'In Progress', 30.0, '2024-01-15', '2024-02-15'),
(4, 'تصميم المواد التسويقية', 'تصميم البانرات والمواد الترويجية', 14, 'Medium', 'Not Started', 20.0, '2024-02-01', '2024-02-28');

PRINT 'تم إدراج جميع البيانات الوهمية بنجاح';

