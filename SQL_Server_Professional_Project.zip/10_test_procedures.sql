-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 10_test_procedures.sql
-- الوصف: اختبار الإجراءات المخزنة والدوال
-- ===================================================

USE CompanyManagementDB;
GO

PRINT '=== بدء اختبار الإجراءات المخزنة والدوال ===';
PRINT '';

-- ===================================================
-- 1. اختبار إضافة موظف جديد
-- ===================================================

PRINT '1. اختبار إضافة موظف جديد:';
EXEC HR.sp_AddEmployee 
    @FirstName = 'علي',
    @LastName = 'الأحمد',
    @Email = 'ali.ahmad@company.com',
    @Phone = '0501234590',
    @HireDate = '2024-01-15',
    @DepartmentID = 1,
    @Position = 'مطور برمجيات متدرب',
    @Salary = 5000.00,
    @ManagerID = 2;

PRINT '';

-- ===================================================
-- 2. اختبار تحديث راتب الموظف
-- ===================================================

PRINT '2. اختبار تحديث راتب الموظف:';
EXEC HR.sp_UpdateEmployeeSalary 
    @EmployeeID = 3,
    @NewSalary = 10000.00,
    @ChangeReason = 'ترقية وزيادة مسؤوليات',
    @ApprovedBy = 1;

PRINT '';

-- ===================================================
-- 3. اختبار إضافة مشروع جديد
-- ===================================================

PRINT '3. اختبار إضافة مشروع جديد:';
EXEC Projects.sp_AddProject 
    @ProjectName = 'تطبيق الهاتف المحمول',
    @ProjectCode = 'MOBILE2024',
    @Description = 'تطوير تطبيق للهواتف الذكية لخدمة العملاء',
    @StartDate = '2024-04-01',
    @EndDate = '2024-09-30',
    @Budget = 180000.00,
    @ProjectManagerID = 2;

PRINT '';

-- ===================================================
-- 4. اختبار تسجيل الحضور
-- ===================================================

PRINT '4. اختبار تسجيل الحضور:';
EXEC HR.sp_RecordAttendance 
    @EmployeeID = 1,
    @AttendanceDate = '2024-01-15',
    @CheckInTime = '08:30:00',
    @CheckOutTime = '17:45:00',
    @Status = 'Present',
    @Notes = 'يوم عمل عادي';

PRINT '';

-- ===================================================
-- 5. اختبار تقرير أداء الموظف
-- ===================================================

PRINT '5. اختبار تقرير أداء الموظف:';
EXEC HR.sp_GetEmployeePerformanceReport 
    @EmployeeID = 1,
    @StartDate = '2024-01-01',
    @EndDate = '2024-01-31';

PRINT '';

-- ===================================================
-- 6. اختبار إنهاء مشروع
-- ===================================================

PRINT '6. اختبار إنهاء مشروع:';
EXEC Projects.sp_CompleteProject 
    @ProjectID = 2,
    @CompletionNotes = 'تم إنهاء المشروع بنجاح وفي الوقت المحدد';

PRINT '';

-- ===================================================
-- 7. اختبار الدوال المخصصة
-- ===================================================

PRINT '7. اختبار الدوال المخصصة:';

-- اختبار دالة حساب سنوات الخدمة
SELECT 
    'سنوات الخدمة للموظف رقم 1' AS Test,
    HR.fn_GetYearsOfService('2020-01-15') AS YearsOfService;

-- اختبار دالة حساب المكافأة السنوية
SELECT 
    'المكافأة السنوية للموظف رقم 1' AS Test,
    HR.fn_CalculateAnnualBonus(1) AS AnnualBonus;

-- اختبار دالة حساب معدل الحضور
SELECT 
    'معدل الحضور للموظف رقم 1' AS Test,
    HR.fn_GetAttendanceRate(1, '2024-01-01', '2024-01-31') AS AttendanceRate;

-- اختبار دالة حساب ساعات العمل الشهرية
SELECT 
    'ساعات العمل الشهرية للموظف رقم 1' AS Test,
    HR.fn_GetMonthlyWorkingHours(1, 2024, 1) AS MonthlyHours;

-- اختبار دالة حساب تقدم المشروع
SELECT 
    'تقدم المشروع رقم 1' AS Test,
    Projects.fn_GetProjectProgress(1) AS ProjectProgress;

-- اختبار دالة حساب تكلفة المشروع
SELECT 
    'تكلفة المشروع رقم 1' AS Test,
    Projects.fn_CalculateProjectCost(1) AS ProjectCost;

-- اختبار دالة تحديد مستوى الأداء
SELECT 
    'مستوى أداء الموظف رقم 1' AS Test,
    HR.fn_GetEmployeePerformanceLevel(1) AS PerformanceLevel;

PRINT '';

-- ===================================================
-- 8. اختبار الدوال الجدولية
-- ===================================================

PRINT '8. اختبار الدوال الجدولية:';

-- اختبار دالة موظفي القسم
SELECT 'موظفو قسم تقنية المعلومات:' AS Test;
SELECT * FROM HR.fn_GetDepartmentEmployees(1);

-- اختبار دالة المشاريع النشطة
SELECT 'المشاريع النشطة مع التقدم:' AS Test;
SELECT * FROM Projects.fn_GetActiveProjectsWithProgress();

PRINT '';

-- ===================================================
-- 9. اختبار المشاهد
-- ===================================================

PRINT '9. اختبار المشاهد:';

-- اختبار مشهد تفاصيل الموظفين
SELECT 'عينة من مشهد تفاصيل الموظفين:' AS Test;
SELECT TOP 5 * FROM HR.vw_EmployeeDetails ORDER BY YearsOfService DESC;

-- اختبار مشهد إحصائيات الأقسام
SELECT 'إحصائيات الأقسام:' AS Test;
SELECT * FROM HR.vw_DepartmentStatistics ORDER BY TotalEmployees DESC;

-- اختبار مشهد تفاصيل المشاريع
SELECT 'تفاصيل المشاريع:' AS Test;
SELECT * FROM Projects.vw_ProjectDetails ORDER BY TeamSize DESC;

PRINT '';

-- ===================================================
-- 10. اختبار سجل التدقيق
-- ===================================================

PRINT '10. عرض سجل التدقيق (آخر 10 عمليات):';
SELECT TOP 10 
    TableName,
    Operation,
    RecordID,
    ChangedBy,
    ChangeDate,
    CASE 
        WHEN LEN(NewValues) > 100 THEN LEFT(NewValues, 100) + '...'
        ELSE NewValues
    END AS NewValues
FROM dbo.AuditLog
ORDER BY ChangeDate DESC;

PRINT '';

-- ===================================================
-- 11. إحصائيات عامة عن قاعدة البيانات
-- ===================================================

PRINT '11. إحصائيات عامة عن قاعدة البيانات:';

SELECT 'إجمالي الموظفين النشطين' AS Statistic, COUNT(*) AS Count FROM HR.Employees WHERE IsActive = 1
UNION ALL
SELECT 'إجمالي الأقسام', COUNT(*) FROM HR.Departments WHERE IsActive = 1
UNION ALL
SELECT 'إجمالي المشاريع', COUNT(*) FROM Projects.Projects
UNION ALL
SELECT 'المشاريع النشطة', COUNT(*) FROM Projects.Projects WHERE Status IN ('Planning', 'In Progress')
UNION ALL
SELECT 'إجمالي المهام', COUNT(*) FROM Projects.Tasks
UNION ALL
SELECT 'المهام المكتملة', COUNT(*) FROM Projects.Tasks WHERE Status = 'Completed'
UNION ALL
SELECT 'سجلات الحضور', COUNT(*) FROM HR.Attendance
UNION ALL
SELECT 'سجلات تاريخ الرواتب', COUNT(*) FROM Finance.SalaryHistory;

PRINT '';
PRINT '=== انتهاء اختبار الإجراءات المخزنة والدوال ===';

-- ===================================================
-- 12. اختبار أداء الاستعلامات
-- ===================================================

PRINT '12. اختبار أداء بعض الاستعلامات:';

-- تشغيل إحصائيات الإدخال/الإخراج
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- استعلام معقد لاختبار الأداء
SELECT 
    d.DepartmentName,
    COUNT(e.EmployeeID) AS EmployeeCount,
    AVG(e.Salary) AS AvgSalary,
    COUNT(DISTINCT ep.ProjectID) AS ProjectCount,
    SUM(ep.HoursAllocated) AS TotalHours
FROM HR.Departments d
LEFT JOIN HR.Employees e ON d.DepartmentID = e.DepartmentID AND e.IsActive = 1
LEFT JOIN Projects.EmployeeProjects ep ON e.EmployeeID = ep.EmployeeID AND ep.IsActive = 1
GROUP BY d.DepartmentID, d.DepartmentName
ORDER BY EmployeeCount DESC;

-- إيقاف إحصائيات الأداء
SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;

PRINT 'تم الانتهاء من جميع الاختبارات بنجاح!';

