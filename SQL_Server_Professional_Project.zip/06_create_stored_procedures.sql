-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 06_create_stored_procedures.sql
-- الوصف: إنشاء الإجراءات المخزنة (Stored Procedures)
-- ===================================================

USE CompanyManagementDB;
GO

-- إجراء لإضافة موظف جديد
CREATE PROCEDURE HR.sp_AddEmployee
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20) = NULL,
    @HireDate DATE,
    @DepartmentID INT,
    @Position NVARCHAR(100),
    @Salary DECIMAL(10,2),
    @ManagerID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- التحقق من وجود القسم
        IF NOT EXISTS (SELECT 1 FROM HR.Departments WHERE DepartmentID = @DepartmentID AND IsActive = 1)
        BEGIN
            RAISERROR('القسم المحدد غير موجود أو غير نشط', 16, 1);
            RETURN;
        END
        
        -- التحقق من عدم تكرار البريد الإلكتروني
        IF EXISTS (SELECT 1 FROM HR.Employees WHERE Email = @Email)
        BEGIN
            RAISERROR('البريد الإلكتروني مستخدم مسبقاً', 16, 1);
            RETURN;
        END
        
        -- إدراج الموظف الجديد
        INSERT INTO HR.Employees (FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary, ManagerID)
        VALUES (@FirstName, @LastName, @Email, @Phone, @HireDate, @DepartmentID, @Position, @Salary, @ManagerID);
        
        DECLARE @NewEmployeeID INT = SCOPE_IDENTITY();
        
        COMMIT TRANSACTION;
        
        SELECT @NewEmployeeID AS NewEmployeeID, 'تم إضافة الموظف بنجاح' AS Message;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
GO

-- إجراء لتحديث راتب الموظف
CREATE PROCEDURE HR.sp_UpdateEmployeeSalary
    @EmployeeID INT,
    @NewSalary DECIMAL(10,2),
    @ChangeReason NVARCHAR(200) = NULL,
    @ApprovedBy INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        DECLARE @OldSalary DECIMAL(10,2);
        
        -- الحصول على الراتب الحالي
        SELECT @OldSalary = Salary 
        FROM HR.Employees 
        WHERE EmployeeID = @EmployeeID AND IsActive = 1;
        
        IF @OldSalary IS NULL
        BEGIN
            RAISERROR('الموظف غير موجود أو غير نشط', 16, 1);
            RETURN;
        END
        
        -- تحديث الراتب
        UPDATE HR.Employees 
        SET Salary = @NewSalary, ModifiedDate = GETDATE()
        WHERE EmployeeID = @EmployeeID;
        
        -- إضافة سجل في تاريخ الرواتب
        INSERT INTO Finance.SalaryHistory (EmployeeID, OldSalary, NewSalary, ChangeReason, ApprovedBy)
        VALUES (@EmployeeID, @OldSalary, @NewSalary, @ChangeReason, @ApprovedBy);
        
        COMMIT TRANSACTION;
        
        SELECT 'تم تحديث الراتب بنجاح' AS Message,
               @OldSalary AS OldSalary,
               @NewSalary AS NewSalary,
               @NewSalary - @OldSalary AS SalaryDifference;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
GO

-- إجراء لإضافة مشروع جديد
CREATE PROCEDURE Projects.sp_AddProject
    @ProjectName NVARCHAR(200),
    @ProjectCode NVARCHAR(20),
    @Description NVARCHAR(MAX) = NULL,
    @StartDate DATE,
    @EndDate DATE = NULL,
    @Budget DECIMAL(15,2),
    @ProjectManagerID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- التحقق من وجود مدير المشروع
        IF NOT EXISTS (SELECT 1 FROM HR.Employees WHERE EmployeeID = @ProjectManagerID AND IsActive = 1)
        BEGIN
            RAISERROR('مدير المشروع غير موجود أو غير نشط', 16, 1);
            RETURN;
        END
        
        -- التحقق من عدم تكرار رمز المشروع
        IF EXISTS (SELECT 1 FROM Projects.Projects WHERE ProjectCode = @ProjectCode)
        BEGIN
            RAISERROR('رمز المشروع مستخدم مسبقاً', 16, 1);
            RETURN;
        END
        
        -- إدراج المشروع الجديد
        INSERT INTO Projects.Projects (ProjectName, ProjectCode, Description, StartDate, EndDate, Budget, ProjectManagerID)
        VALUES (@ProjectName, @ProjectCode, @Description, @StartDate, @EndDate, @Budget, @ProjectManagerID);
        
        DECLARE @NewProjectID INT = SCOPE_IDENTITY();
        
        COMMIT TRANSACTION;
        
        SELECT @NewProjectID AS NewProjectID, 'تم إضافة المشروع بنجاح' AS Message;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
GO

-- إجراء لتسجيل الحضور
CREATE PROCEDURE HR.sp_RecordAttendance
    @EmployeeID INT,
    @AttendanceDate DATE = NULL,
    @CheckInTime TIME = NULL,
    @CheckOutTime TIME = NULL,
    @Status NVARCHAR(20) = 'Present',
    @Notes NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @AttendanceDate IS NULL
        SET @AttendanceDate = CAST(GETDATE() AS DATE);
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- التحقق من وجود الموظف
        IF NOT EXISTS (SELECT 1 FROM HR.Employees WHERE EmployeeID = @EmployeeID AND IsActive = 1)
        BEGIN
            RAISERROR('الموظف غير موجود أو غير نشط', 16, 1);
            RETURN;
        END
        
        -- التحقق من عدم وجود سجل حضور لنفس اليوم
        IF EXISTS (SELECT 1 FROM HR.Attendance WHERE EmployeeID = @EmployeeID AND AttendanceDate = @AttendanceDate)
        BEGIN
            -- تحديث السجل الموجود
            UPDATE HR.Attendance 
            SET CheckInTime = ISNULL(@CheckInTime, CheckInTime),
                CheckOutTime = ISNULL(@CheckOutTime, CheckOutTime),
                Status = @Status,
                Notes = @Notes
            WHERE EmployeeID = @EmployeeID AND AttendanceDate = @AttendanceDate;
            
            SELECT 'تم تحديث سجل الحضور' AS Message;
        END
        ELSE
        BEGIN
            -- إدراج سجل جديد
            INSERT INTO HR.Attendance (EmployeeID, AttendanceDate, CheckInTime, CheckOutTime, Status, Notes)
            VALUES (@EmployeeID, @AttendanceDate, @CheckInTime, @CheckOutTime, @Status, @Notes);
            
            SELECT 'تم تسجيل الحضور بنجاح' AS Message;
        END
        
        COMMIT TRANSACTION;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
GO

-- إجراء للحصول على تقرير أداء الموظف
CREATE PROCEDURE HR.sp_GetEmployeePerformanceReport
    @EmployeeID INT = NULL,
    @DepartmentID INT = NULL,
    @StartDate DATE = NULL,
    @EndDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @StartDate IS NULL
        SET @StartDate = DATEADD(MONTH, -3, GETDATE()); -- آخر 3 أشهر افتراضياً
    
    IF @EndDate IS NULL
        SET @EndDate = GETDATE();
    
    SELECT 
        e.EmployeeID,
        e.FirstName + ' ' + e.LastName AS EmployeeName,
        e.Position,
        d.DepartmentName,
        
        -- إحصائيات الحضور
        COUNT(DISTINCT a.AttendanceDate) AS TotalWorkingDays,
        SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS PresentDays,
        CAST(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0 / 
             NULLIF(COUNT(DISTINCT a.AttendanceDate), 0) AS DECIMAL(5,2)) AS AttendanceRate,
        AVG(a.WorkingHours) AS AverageWorkingHours,
        
        -- إحصائيات المشاريع
        COUNT(DISTINCT ep.ProjectID) AS ActiveProjects,
        SUM(ep.HoursAllocated) AS TotalAllocatedHours,
        
        -- إحصائيات المهام
        COUNT(DISTINCT t.TaskID) AS TotalTasks,
        COUNT(DISTINCT CASE WHEN t.Status = 'Completed' THEN t.TaskID END) AS CompletedTasks,
        CAST(COUNT(DISTINCT CASE WHEN t.Status = 'Completed' THEN t.TaskID END) * 100.0 / 
             NULLIF(COUNT(DISTINCT t.TaskID), 0) AS DECIMAL(5,2)) AS TaskCompletionRate,
        
        -- معلومات إضافية
        e.Salary,
        DATEDIFF(YEAR, e.HireDate, GETDATE()) AS YearsOfService
        
    FROM HR.Employees e
    INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
    LEFT JOIN HR.Attendance a ON e.EmployeeID = a.EmployeeID 
        AND a.AttendanceDate BETWEEN @StartDate AND @EndDate
    LEFT JOIN Projects.EmployeeProjects ep ON e.EmployeeID = ep.EmployeeID 
        AND ep.IsActive = 1
    LEFT JOIN Projects.Tasks t ON e.EmployeeID = t.AssignedTo
        AND t.CreatedDate BETWEEN @StartDate AND @EndDate
    
    WHERE e.IsActive = 1
        AND (@EmployeeID IS NULL OR e.EmployeeID = @EmployeeID)
        AND (@DepartmentID IS NULL OR e.DepartmentID = @DepartmentID)
    
    GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Position, 
             d.DepartmentName, e.Salary, e.HireDate
    
    ORDER BY e.FirstName, e.LastName;
END;
GO

-- إجراء لإنهاء مشروع
CREATE PROCEDURE Projects.sp_CompleteProject
    @ProjectID INT,
    @CompletionNotes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        BEGIN TRANSACTION;
        
        -- التحقق من وجود المشروع
        IF NOT EXISTS (SELECT 1 FROM Projects.Projects WHERE ProjectID = @ProjectID)
        BEGIN
            RAISERROR('المشروع غير موجود', 16, 1);
            RETURN;
        END
        
        -- تحديث حالة المشروع
        UPDATE Projects.Projects 
        SET Status = 'Completed',
            EndDate = CASE WHEN EndDate IS NULL THEN CAST(GETDATE() AS DATE) ELSE EndDate END
        WHERE ProjectID = @ProjectID;
        
        -- تحديث حالة جميع المهام المفتوحة إلى مكتملة
        UPDATE Projects.Tasks 
        SET Status = 'Completed',
            CompletedDate = GETDATE()
        WHERE ProjectID = @ProjectID 
            AND Status IN ('Not Started', 'In Progress', 'On Hold');
        
        COMMIT TRANSACTION;
        
        SELECT 'تم إنهاء المشروع بنجاح' AS Message,
               (SELECT COUNT(*) FROM Projects.Tasks WHERE ProjectID = @ProjectID) AS TotalTasks,
               (SELECT COUNT(*) FROM Projects.Tasks WHERE ProjectID = @ProjectID AND Status = 'Completed') AS CompletedTasks;
        
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
GO

PRINT 'تم إنشاء جميع الإجراءات المخزنة بنجاح';

