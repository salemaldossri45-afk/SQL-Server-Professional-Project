-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 05_create_views.sql
-- الوصف: إنشاء المشاهد (Views) لتبسيط الاستعلامات
-- ===================================================

USE CompanyManagementDB;
GO

-- مشهد تفاصيل الموظفين مع معلومات القسم
CREATE VIEW HR.vw_EmployeeDetails
AS
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS FullName,
    e.Email,
    e.Phone,
    e.HireDate,
    e.Position,
    e.Salary,
    d.DepartmentName,
    d.DepartmentCode,
    m.FirstName + ' ' + m.LastName AS ManagerName,
    DATEDIFF(YEAR, e.HireDate, GETDATE()) AS YearsOfService,
    CASE 
        WHEN e.IsActive = 1 THEN 'نشط'
        ELSE 'غير نشط'
    END AS Status
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
LEFT JOIN HR.Employees m ON e.ManagerID = m.EmployeeID
WHERE e.IsActive = 1;
GO

-- مشهد إحصائيات الأقسام
CREATE VIEW HR.vw_DepartmentStatistics
AS
SELECT 
    d.DepartmentID,
    d.DepartmentName,
    d.DepartmentCode,
    COUNT(e.EmployeeID) AS TotalEmployees,
    AVG(e.Salary) AS AverageSalary,
    MIN(e.Salary) AS MinSalary,
    MAX(e.Salary) AS MaxSalary,
    SUM(e.Salary) AS TotalSalaryBudget,
    d.Budget AS DepartmentBudget,
    d.Budget - SUM(e.Salary) AS RemainingBudget,
    m.FirstName + ' ' + m.LastName AS ManagerName
FROM HR.Departments d
LEFT JOIN HR.Employees e ON d.DepartmentID = e.DepartmentID AND e.IsActive = 1
LEFT JOIN HR.Employees m ON d.ManagerID = m.EmployeeID
GROUP BY d.DepartmentID, d.DepartmentName, d.DepartmentCode, d.Budget, 
         m.FirstName, m.LastName;
GO

-- مشهد تفاصيل المشاريع مع معلومات المدير
CREATE VIEW Projects.vw_ProjectDetails
AS
SELECT 
    p.ProjectID,
    p.ProjectName,
    p.ProjectCode,
    p.Description,
    p.StartDate,
    p.EndDate,
    p.Budget,
    p.Status,
    pm.FirstName + ' ' + pm.LastName AS ProjectManagerName,
    pm.Email AS ProjectManagerEmail,
    DATEDIFF(DAY, p.StartDate, ISNULL(p.EndDate, GETDATE())) AS ProjectDurationDays,
    COUNT(ep.EmployeeID) AS TeamSize,
    SUM(ep.HoursAllocated) AS TotalAllocatedHours
FROM Projects.Projects p
INNER JOIN HR.Employees pm ON p.ProjectManagerID = pm.EmployeeID
LEFT JOIN Projects.EmployeeProjects ep ON p.ProjectID = ep.ProjectID AND ep.IsActive = 1
GROUP BY p.ProjectID, p.ProjectName, p.ProjectCode, p.Description, 
         p.StartDate, p.EndDate, p.Budget, p.Status,
         pm.FirstName, pm.LastName, pm.Email;
GO

-- مشهد تفاصيل المهام مع معلومات الموظف والمشروع
CREATE VIEW Projects.vw_TaskDetails
AS
SELECT 
    t.TaskID,
    t.TaskName,
    t.Description,
    t.Priority,
    t.Status,
    t.EstimatedHours,
    t.ActualHours,
    t.StartDate,
    t.DueDate,
    t.CompletedDate,
    p.ProjectName,
    p.ProjectCode,
    e.FirstName + ' ' + e.LastName AS AssignedToName,
    e.Email AS AssignedToEmail,
    CASE 
        WHEN t.Status = 'Completed' THEN 100
        WHEN t.Status = 'In Progress' THEN 50
        WHEN t.Status = 'On Hold' THEN 25
        ELSE 0
    END AS CompletionPercentage,
    CASE 
        WHEN t.DueDate < GETDATE() AND t.Status != 'Completed' THEN 'متأخر'
        WHEN t.DueDate = CAST(GETDATE() AS DATE) AND t.Status != 'Completed' THEN 'مستحق اليوم'
        WHEN DATEDIFF(DAY, GETDATE(), t.DueDate) <= 3 AND t.Status != 'Completed' THEN 'مستحق قريباً'
        ELSE 'في الوقت المحدد'
    END AS TaskUrgency
FROM Projects.Tasks t
INNER JOIN Projects.Projects p ON t.ProjectID = p.ProjectID
INNER JOIN HR.Employees e ON t.AssignedTo = e.EmployeeID;
GO

-- مشهد إحصائيات الحضور الشهرية
CREATE VIEW HR.vw_MonthlyAttendanceStats
AS
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    d.DepartmentName,
    YEAR(a.AttendanceDate) AS Year,
    MONTH(a.AttendanceDate) AS Month,
    COUNT(*) AS TotalWorkingDays,
    SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS PresentDays,
    SUM(CASE WHEN a.Status = 'Absent' THEN 1 ELSE 0 END) AS AbsentDays,
    SUM(CASE WHEN a.Status = 'Late' THEN 1 ELSE 0 END) AS LateDays,
    AVG(a.WorkingHours) AS AverageWorkingHours,
    SUM(a.WorkingHours) AS TotalWorkingHours,
    CAST(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendancePercentage
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
INNER JOIN HR.Attendance a ON e.EmployeeID = a.EmployeeID
WHERE e.IsActive = 1
GROUP BY e.EmployeeID, e.FirstName, e.LastName, d.DepartmentName,
         YEAR(a.AttendanceDate), MONTH(a.AttendanceDate);
GO

-- مشهد تقرير الرواتب
CREATE VIEW Finance.vw_SalaryReport
AS
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    e.Position,
    d.DepartmentName,
    e.Salary AS CurrentSalary,
    e.HireDate,
    DATEDIFF(YEAR, e.HireDate, GETDATE()) AS YearsOfService,
    CASE 
        WHEN DATEDIFF(YEAR, e.HireDate, GETDATE()) >= 5 THEN e.Salary * 0.1
        WHEN DATEDIFF(YEAR, e.HireDate, GETDATE()) >= 3 THEN e.Salary * 0.05
        ELSE 0
    END AS EligibleBonus,
    (SELECT COUNT(*) FROM Finance.SalaryHistory sh WHERE sh.EmployeeID = e.EmployeeID) AS SalaryChanges,
    (SELECT MAX(sh.ChangeDate) FROM Finance.SalaryHistory sh WHERE sh.EmployeeID = e.EmployeeID) AS LastSalaryChange
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
WHERE e.IsActive = 1;
GO

-- مشهد أداء الموظفين في المشاريع
CREATE VIEW Projects.vw_EmployeeProjectPerformance
AS
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    COUNT(DISTINCT ep.ProjectID) AS TotalProjects,
    COUNT(DISTINCT CASE WHEN p.Status = 'Completed' THEN ep.ProjectID END) AS CompletedProjects,
    COUNT(DISTINCT CASE WHEN p.Status = 'In Progress' THEN ep.ProjectID END) AS ActiveProjects,
    SUM(ep.HoursAllocated) AS TotalAllocatedHours,
    AVG(ep.HoursAllocated) AS AverageHoursPerProject,
    COUNT(DISTINCT t.TaskID) AS TotalTasks,
    COUNT(DISTINCT CASE WHEN t.Status = 'Completed' THEN t.TaskID END) AS CompletedTasks,
    CAST(COUNT(DISTINCT CASE WHEN t.Status = 'Completed' THEN t.TaskID END) * 100.0 / 
         NULLIF(COUNT(DISTINCT t.TaskID), 0) AS DECIMAL(5,2)) AS TaskCompletionRate
FROM HR.Employees e
LEFT JOIN Projects.EmployeeProjects ep ON e.EmployeeID = ep.EmployeeID AND ep.IsActive = 1
LEFT JOIN Projects.Projects p ON ep.ProjectID = p.ProjectID
LEFT JOIN Projects.Tasks t ON e.EmployeeID = t.AssignedTo
WHERE e.IsActive = 1
GROUP BY e.EmployeeID, e.FirstName, e.LastName;
GO

PRINT 'تم إنشاء جميع المشاهد (Views) بنجاح';

