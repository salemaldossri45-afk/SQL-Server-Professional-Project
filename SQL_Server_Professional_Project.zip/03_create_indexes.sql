-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 03_create_indexes.sql
-- الوصف: إنشاء الفهارس لتحسين الأداء
-- ===================================================

USE CompanyManagementDB;
GO

-- فهارس جدول الموظفين
CREATE NONCLUSTERED INDEX IX_Employees_DepartmentID 
    ON HR.Employees (DepartmentID);

CREATE NONCLUSTERED INDEX IX_Employees_ManagerID 
    ON HR.Employees (ManagerID);

CREATE NONCLUSTERED INDEX IX_Employees_Email 
    ON HR.Employees (Email);

CREATE NONCLUSTERED INDEX IX_Employees_HireDate 
    ON HR.Employees (HireDate);

CREATE NONCLUSTERED INDEX IX_Employees_IsActive 
    ON HR.Employees (IsActive);

-- فهارس جدول المشاريع
CREATE NONCLUSTERED INDEX IX_Projects_ProjectManagerID 
    ON Projects.Projects (ProjectManagerID);

CREATE NONCLUSTERED INDEX IX_Projects_Status 
    ON Projects.Projects (Status);

CREATE NONCLUSTERED INDEX IX_Projects_StartDate 
    ON Projects.Projects (StartDate);

CREATE NONCLUSTERED INDEX IX_Projects_EndDate 
    ON Projects.Projects (EndDate);

-- فهارس جدول ربط الموظفين بالمشاريع
CREATE NONCLUSTERED INDEX IX_EmployeeProjects_EmployeeID 
    ON Projects.EmployeeProjects (EmployeeID);

CREATE NONCLUSTERED INDEX IX_EmployeeProjects_ProjectID 
    ON Projects.EmployeeProjects (ProjectID);

CREATE NONCLUSTERED INDEX IX_EmployeeProjects_IsActive 
    ON Projects.EmployeeProjects (IsActive);

-- فهارس جدول الحضور
CREATE NONCLUSTERED INDEX IX_Attendance_EmployeeID 
    ON HR.Attendance (EmployeeID);

CREATE NONCLUSTERED INDEX IX_Attendance_Date 
    ON HR.Attendance (AttendanceDate);

CREATE NONCLUSTERED INDEX IX_Attendance_Status 
    ON HR.Attendance (Status);

-- فهارس جدول تاريخ الرواتب
CREATE NONCLUSTERED INDEX IX_SalaryHistory_EmployeeID 
    ON Finance.SalaryHistory (EmployeeID);

CREATE NONCLUSTERED INDEX IX_SalaryHistory_ChangeDate 
    ON Finance.SalaryHistory (ChangeDate);

-- فهارس جدول المهام
CREATE NONCLUSTERED INDEX IX_Tasks_ProjectID 
    ON Projects.Tasks (ProjectID);

CREATE NONCLUSTERED INDEX IX_Tasks_AssignedTo 
    ON Projects.Tasks (AssignedTo);

CREATE NONCLUSTERED INDEX IX_Tasks_Status 
    ON Projects.Tasks (Status);

CREATE NONCLUSTERED INDEX IX_Tasks_Priority 
    ON Projects.Tasks (Priority);

CREATE NONCLUSTERED INDEX IX_Tasks_DueDate 
    ON Projects.Tasks (DueDate);

-- فهرس مركب لتحسين استعلامات معينة
CREATE NONCLUSTERED INDEX IX_Employees_Department_Active 
    ON HR.Employees (DepartmentID, IsActive) 
    INCLUDE (FirstName, LastName, Position, Salary);

CREATE NONCLUSTERED INDEX IX_Projects_Status_Manager 
    ON Projects.Projects (Status, ProjectManagerID) 
    INCLUDE (ProjectName, StartDate, EndDate, Budget);

PRINT 'تم إنشاء جميع الفهارس بنجاح';

