-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 11_performance_optimization.sql
-- الوصف: تحسين أداء قاعدة البيانات
-- ===================================================

USE CompanyManagementDB;
GO

-- ===================================================
-- 1. إنشاء فهارس إضافية لتحسين الأداء
-- ===================================================

-- فهرس مركب لتحسين استعلامات البحث عن الموظفين
CREATE NONCLUSTERED INDEX IX_Employees_Name_Department 
    ON HR.Employees (LastName, FirstName, DepartmentID) 
    INCLUDE (Email, Position, Salary, HireDate)
    WHERE IsActive = 1;

-- فهرس لتحسين استعلامات المشاريع حسب التاريخ والحالة
CREATE NONCLUSTERED INDEX IX_Projects_DateStatus 
    ON Projects.Projects (StartDate, Status) 
    INCLUDE (ProjectName, Budget, ProjectManagerID);

-- فهرس لتحسين استعلامات المهام حسب الموظف والحالة
CREATE NONCLUSTERED INDEX IX_Tasks_Employee_Status 
    ON Projects.Tasks (AssignedTo, Status) 
    INCLUDE (TaskName, Priority, DueDate, EstimatedHours);

-- فهرس لتحسين استعلامات الحضور حسب التاريخ
CREATE NONCLUSTERED INDEX IX_Attendance_Date_Employee 
    ON HR.Attendance (AttendanceDate, EmployeeID) 
    INCLUDE (Status, WorkingHours);

-- ===================================================
-- 2. إنشاء إحصائيات مخصصة
-- ===================================================

-- إنشاء إحصائيات للأعمدة المستخدمة بكثرة في WHERE clauses
CREATE STATISTICS STAT_Employees_Salary ON HR.Employees (Salary);
CREATE STATISTICS STAT_Projects_Budget ON Projects.Projects (Budget);
CREATE STATISTICS STAT_Tasks_EstimatedHours ON Projects.Tasks (EstimatedHours);

-- ===================================================
-- 3. تحسين الاستعلامات الموجودة
-- ===================================================

-- استعلام محسن للحصول على تفاصيل الموظفين
CREATE VIEW HR.vw_EmployeeDetailsOptimized
WITH SCHEMABINDING
AS
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    e.Email,
    e.Position,
    e.Salary,
    e.HireDate,
    e.DepartmentID,
    d.DepartmentName,
    e.ManagerID
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
WHERE e.IsActive = 1;
GO

-- إنشاء فهرس على المشهد المحسن
CREATE UNIQUE CLUSTERED INDEX IX_vw_EmployeeDetailsOptimized_EmployeeID 
    ON HR.vw_EmployeeDetailsOptimized (EmployeeID);

CREATE NONCLUSTERED INDEX IX_vw_EmployeeDetailsOptimized_Department 
    ON HR.vw_EmployeeDetailsOptimized (DepartmentID, LastName, FirstName);

-- ===================================================
-- 4. إجراءات مخزنة محسنة للأداء
-- ===================================================

-- إجراء محسن للبحث عن الموظفين
CREATE PROCEDURE HR.sp_SearchEmployeesOptimized
    @SearchTerm NVARCHAR(100) = NULL,
    @DepartmentID INT = NULL,
    @MinSalary DECIMAL(10,2) = NULL,
    @MaxSalary DECIMAL(10,2) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 20
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;
    
    WITH SearchResults AS (
        SELECT 
            e.EmployeeID,
            e.FirstName + ' ' + e.LastName AS FullName,
            e.Email,
            e.Position,
            e.Salary,
            d.DepartmentName,
            ROW_NUMBER() OVER (ORDER BY e.LastName, e.FirstName) AS RowNum
        FROM HR.Employees e
        INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
        WHERE e.IsActive = 1
            AND (@SearchTerm IS NULL OR 
                 e.FirstName LIKE '%' + @SearchTerm + '%' OR 
                 e.LastName LIKE '%' + @SearchTerm + '%' OR
                 e.Email LIKE '%' + @SearchTerm + '%')
            AND (@DepartmentID IS NULL OR e.DepartmentID = @DepartmentID)
            AND (@MinSalary IS NULL OR e.Salary >= @MinSalary)
            AND (@MaxSalary IS NULL OR e.Salary <= @MaxSalary)
    )
    SELECT 
        EmployeeID,
        FullName,
        Email,
        Position,
        Salary,
        DepartmentName,
        (SELECT COUNT(*) FROM SearchResults) AS TotalRecords
    FROM SearchResults
    WHERE RowNum > @Offset AND RowNum <= @Offset + @PageSize
    ORDER BY RowNum;
END;
GO

-- ===================================================
-- 5. تحسين إعدادات قاعدة البيانات
-- ===================================================

-- تحسين إعدادات قاعدة البيانات للأداء
ALTER DATABASE CompanyManagementDB SET AUTO_UPDATE_STATISTICS ON;
ALTER DATABASE CompanyManagementDB SET AUTO_CREATE_STATISTICS ON;
ALTER DATABASE CompanyManagementDB SET AUTO_UPDATE_STATISTICS_ASYNC ON;

-- تحسين إعدادات الذاكرة
ALTER DATABASE CompanyManagementDB SET TARGET_RECOVERY_TIME = 60 SECONDS;

-- ===================================================
-- 6. إنشاء جدول للمراقبة والتحليل
-- ===================================================

CREATE TABLE dbo.PerformanceMonitoring (
    MonitoringID INT IDENTITY(1,1) PRIMARY KEY,
    QueryType NVARCHAR(100) NOT NULL,
    ExecutionTime DATETIME2 DEFAULT GETDATE(),
    Duration_ms INT,
    LogicalReads INT,
    PhysicalReads INT,
    CPU_ms INT,
    QueryText NVARCHAR(MAX),
    ExecutionPlan XML
);
GO

-- إجراء لتسجيل أداء الاستعلامات
CREATE PROCEDURE dbo.sp_LogQueryPerformance
    @QueryType NVARCHAR(100),
    @Duration_ms INT,
    @LogicalReads INT = NULL,
    @PhysicalReads INT = NULL,
    @CPU_ms INT = NULL,
    @QueryText NVARCHAR(MAX) = NULL
AS
BEGIN
    INSERT INTO dbo.PerformanceMonitoring 
    (QueryType, Duration_ms, LogicalReads, PhysicalReads, CPU_ms, QueryText)
    VALUES 
    (@QueryType, @Duration_ms, @LogicalReads, @PhysicalReads, @CPU_ms, @QueryText);
END;
GO

-- ===================================================
-- 7. إجراءات صيانة دورية
-- ===================================================

-- إجراء لإعادة تنظيم الفهارس
CREATE PROCEDURE dbo.sp_MaintenanceIndexes
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @TableName NVARCHAR(128);
    DECLARE @IndexName NVARCHAR(128);
    DECLARE @FragmentationPercent FLOAT;
    DECLARE @SQL NVARCHAR(MAX);
    
    DECLARE index_cursor CURSOR FOR
    SELECT 
        OBJECT_NAME(ips.object_id) AS TableName,
        i.name AS IndexName,
        ips.avg_fragmentation_in_percent
    FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ips
    INNER JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id
    WHERE ips.avg_fragmentation_in_percent > 10
        AND ips.page_count > 100
        AND i.name IS NOT NULL;
    
    OPEN index_cursor;
    FETCH NEXT FROM index_cursor INTO @TableName, @IndexName, @FragmentationPercent;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @FragmentationPercent > 30
        BEGIN
            -- إعادة بناء الفهرس
            SET @SQL = 'ALTER INDEX [' + @IndexName + '] ON [' + @TableName + '] REBUILD WITH (ONLINE = OFF)';
            PRINT 'Rebuilding index: ' + @IndexName + ' on table: ' + @TableName;
        END
        ELSE
        BEGIN
            -- إعادة تنظيم الفهرس
            SET @SQL = 'ALTER INDEX [' + @IndexName + '] ON [' + @TableName + '] REORGANIZE';
            PRINT 'Reorganizing index: ' + @IndexName + ' on table: ' + @TableName;
        END
        
        EXEC sp_executesql @SQL;
        
        FETCH NEXT FROM index_cursor INTO @TableName, @IndexName, @FragmentationPercent;
    END
    
    CLOSE index_cursor;
    DEALLOCATE index_cursor;
    
    -- تحديث الإحصائيات
    EXEC sp_updatestats;
    
    PRINT 'Index maintenance completed successfully.';
END;
GO

-- ===================================================
-- 8. مراقبة الأداء
-- ===================================================

-- مشهد لمراقبة أداء الاستعلامات
CREATE VIEW dbo.vw_QueryPerformanceMonitoring
AS
SELECT 
    QueryType,
    COUNT(*) AS ExecutionCount,
    AVG(Duration_ms) AS AvgDuration_ms,
    MIN(Duration_ms) AS MinDuration_ms,
    MAX(Duration_ms) AS MaxDuration_ms,
    AVG(LogicalReads) AS AvgLogicalReads,
    AVG(PhysicalReads) AS AvgPhysicalReads,
    AVG(CPU_ms) AS AvgCPU_ms,
    MAX(ExecutionTime) AS LastExecution
FROM dbo.PerformanceMonitoring
GROUP BY QueryType;
GO

-- إجراء لتحليل أداء قاعدة البيانات
CREATE PROCEDURE dbo.sp_AnalyzeDatabasePerformance
AS
BEGIN
    SET NOCOUNT ON;
    
    -- إحصائيات الفهارس
    SELECT 
        'Index Statistics' AS ReportType,
        OBJECT_NAME(ips.object_id) AS TableName,
        i.name AS IndexName,
        ips.avg_fragmentation_in_percent AS FragmentationPercent,
        ips.page_count AS PageCount,
        CASE 
            WHEN ips.avg_fragmentation_in_percent > 30 THEN 'Rebuild Required'
            WHEN ips.avg_fragmentation_in_percent > 10 THEN 'Reorganize Required'
            ELSE 'Good'
        END AS Recommendation
    FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ips
    INNER JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id
    WHERE i.name IS NOT NULL
        AND ips.page_count > 100
    ORDER BY ips.avg_fragmentation_in_percent DESC;
    
    -- إحصائيات الجداول
    SELECT 
        'Table Statistics' AS ReportType,
        t.name AS TableName,
        p.rows AS RowCount,
        (SUM(a.total_pages) * 8) / 1024 AS TotalSpaceMB,
        (SUM(a.used_pages) * 8) / 1024 AS UsedSpaceMB,
        ((SUM(a.total_pages) - SUM(a.used_pages)) * 8) / 1024 AS UnusedSpaceMB
    FROM sys.tables t
    INNER JOIN sys.indexes i ON t.object_id = i.object_id
    INNER JOIN sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
    INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
    WHERE i.index_id <= 1
    GROUP BY t.name, p.rows
    ORDER BY p.rows DESC;
    
    -- أداء الاستعلامات
    SELECT 
        'Query Performance' AS ReportType,
        * 
    FROM dbo.vw_QueryPerformanceMonitoring
    ORDER BY AvgDuration_ms DESC;
END;
GO

-- ===================================================
-- 9. تحسين خطط التنفيذ
-- ===================================================

-- إنشاء Plan Guides للاستعلامات المهمة
-- (هذا مثال - يجب تخصيصه حسب الاستعلامات الفعلية)

-- مثال على تحسين استعلام معين
CREATE PROCEDURE HR.sp_GetEmployeesByDepartmentOptimized
    @DepartmentID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- استخدام hint لتحسين الأداء
    SELECT 
        e.EmployeeID,
        e.FirstName + ' ' + e.LastName AS FullName,
        e.Position,
        e.Salary,
        e.Email
    FROM HR.Employees e WITH (INDEX(IX_Employees_DepartmentID))
    WHERE e.DepartmentID = @DepartmentID 
        AND e.IsActive = 1
    ORDER BY e.LastName, e.FirstName
    OPTION (OPTIMIZE FOR (@DepartmentID = 1));
END;
GO

-- ===================================================
-- 10. تنظيف البيانات القديمة
-- ===================================================

-- إجراء لتنظيف سجلات المراقبة القديمة
CREATE PROCEDURE dbo.sp_CleanupOldData
    @DaysToKeep INT = 90
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @CutoffDate DATETIME2 = DATEADD(DAY, -@DaysToKeep, GETDATE());
    
    -- حذف سجلات المراقبة القديمة
    DELETE FROM dbo.PerformanceMonitoring 
    WHERE ExecutionTime < @CutoffDate;
    
    -- حذف سجلات التدقيق القديمة (الاحتفاظ بسنة واحدة)
    DELETE FROM dbo.AuditLog 
    WHERE ChangeDate < DATEADD(YEAR, -1, GETDATE());
    
    PRINT 'Old data cleanup completed successfully.';
END;
GO

PRINT 'تم إنشاء جميع تحسينات الأداء بنجاح';

