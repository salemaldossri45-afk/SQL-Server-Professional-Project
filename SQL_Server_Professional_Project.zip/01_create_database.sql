-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 01_create_database.sql
-- الوصف: إنشاء قاعدة البيانات الرئيسية
-- ===================================================

-- إنشاء قاعدة البيانات
CREATE DATABASE CompanyManagementDB;
GO

-- استخدام قاعدة البيانات
USE CompanyManagementDB;
GO

-- إنشاء Schema منفصل للتنظيم
CREATE SCHEMA HR;
GO

CREATE SCHEMA Projects;
GO

CREATE SCHEMA Finance;
GO

PRINT 'تم إنشاء قاعدة البيانات CompanyManagementDB بنجاح';

