-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 07_create_functions.sql
-- الوصف: إنشاء الدوال (Functions) للحسابات المعقدة
-- ===================================================

USE CompanyManagementDB;
GO

-- دالة لحساب عدد سنوات الخدمة
CREATE FUNCTION HR.fn_GetYearsOfService(@HireDate DATE)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(YEAR, @HireDate, GETDATE());
END;
GO

-- دالة لحساب المكافأة السنوية بناءً على سنوات الخدمة والراتب
CREATE FUNCTION HR.fn_CalculateAnnualBonus(@EmployeeID INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Salary DECIMAL(10,2);
    DECLARE @YearsOfService INT;
    DECLARE @Bonus DECIMAL(10,2) = 0;
    
    SELECT @Salary = Salary, @YearsOfService = DATEDIFF(YEAR, HireDate, GETDATE())
    FROM HR.Employees
    WHERE EmployeeID = @EmployeeID AND IsActive = 1;
    
    IF @Salary IS NOT NULL
    BEGIN
        SET @Bonus = CASE 
            WHEN @YearsOfService >= 10 THEN @Salary * 0.20  -- 20% للموظفين مع 10+ سنوات
            WHEN @YearsOfService >= 5 THEN @Salary * 0.15   -- 15% للموظفين مع 5-9 سنوات
            WHEN @YearsOfService >= 3 THEN @Salary * 0.10   -- 10% للموظفين مع 3-4 سنوات
            WHEN @YearsOfService >= 1 THEN @Salary * 0.05   -- 5% للموظفين مع 1-2 سنة
            ELSE 0                                           -- لا مكافأة للموظفين الجدد
        END;
    END
    
    RETURN @Bonus;
END;
GO

-- دالة لحساب معدل الحضور للموظف في فترة معينة
CREATE FUNCTION HR.fn_GetAttendanceRate(@EmployeeID INT, @StartDate DATE, @EndDate DATE)
RETURNS DECIMAL(5,2)
AS
BEGIN
    DECLARE @TotalDays INT;
    DECLARE @PresentDays INT;
    DECLARE @AttendanceRate DECIMAL(5,2) = 0;
    
    SELECT 
        @TotalDays = COUNT(*),
        @PresentDays = SUM(CASE WHEN Status = 'Present' THEN 1 ELSE 0 END)
    FROM HR.Attendance
    WHERE EmployeeID = @EmployeeID 
        AND AttendanceDate BETWEEN @StartDate AND @EndDate;
    
    IF @TotalDays > 0
        SET @AttendanceRate = (@PresentDays * 100.0) / @TotalDays;
    
    RETURN @AttendanceRate;
END;
GO

-- دالة لحساب إجمالي ساعات العمل للموظف في شهر معين
CREATE FUNCTION HR.fn_GetMonthlyWorkingHours(@EmployeeID INT, @Year INT, @Month INT)
RETURNS DECIMAL(8,2)
AS
BEGIN
    DECLARE @TotalHours DECIMAL(8,2) = 0;
    
    SELECT @TotalHours = ISNULL(SUM(WorkingHours), 0)
    FROM HR.Attendance
    WHERE EmployeeID = @EmployeeID 
        AND YEAR(AttendanceDate) = @Year 
        AND MONTH(AttendanceDate) = @Month
        AND Status = 'Present';
    
    RETURN @TotalHours;
END;
GO

-- دالة لحساب تقدم المشروع (نسبة المهام المكتملة)
CREATE FUNCTION Projects.fn_GetProjectProgress(@ProjectID INT)
RETURNS DECIMAL(5,2)
AS
BEGIN
    DECLARE @TotalTasks INT;
    DECLARE @CompletedTasks INT;
    DECLARE @Progress DECIMAL(5,2) = 0;
    
    SELECT 
        @TotalTasks = COUNT(*),
        @CompletedTasks = SUM(CASE WHEN Status = 'Completed' THEN 1 ELSE 0 END)
    FROM Projects.Tasks
    WHERE ProjectID = @ProjectID;
    
    IF @TotalTasks > 0
        SET @Progress = (@CompletedTasks * 100.0) / @TotalTasks;
    
    RETURN @Progress;
END;
GO

-- دالة لحساب التكلفة المقدرة للمشروع بناءً على ساعات الموظفين
CREATE FUNCTION Projects.fn_CalculateProjectCost(@ProjectID INT)
RETURNS DECIMAL(15,2)
AS
BEGIN
    DECLARE @TotalCost DECIMAL(15,2) = 0;
    
    SELECT @TotalCost = SUM(ep.HoursAllocated * (e.Salary / 160)) -- افتراض 160 ساعة عمل شهرياً
    FROM Projects.EmployeeProjects ep
    INNER JOIN HR.Employees e ON ep.EmployeeID = e.EmployeeID
    WHERE ep.ProjectID = @ProjectID AND ep.IsActive = 1;
    
    RETURN ISNULL(@TotalCost, 0);
END;
GO

-- دالة لتحديد مستوى أداء الموظف بناءً على معايير متعددة
CREATE FUNCTION HR.fn_GetEmployeePerformanceLevel(@EmployeeID INT)
RETURNS NVARCHAR(20)
AS
BEGIN
    DECLARE @AttendanceRate DECIMAL(5,2);
    DECLARE @TaskCompletionRate DECIMAL(5,2);
    DECLARE @YearsOfService INT;
    DECLARE @PerformanceLevel NVARCHAR(20) = 'متوسط';
    
    -- حساب معدل الحضور لآخر 3 أشهر
    SET @AttendanceRate = HR.fn_GetAttendanceRate(@EmployeeID, DATEADD(MONTH, -3, GETDATE()), GETDATE());
    
    -- حساب معدل إنجاز المهام
    SELECT @TaskCompletionRate = CASE 
        WHEN COUNT(*) = 0 THEN 100 -- إذا لم تكن هناك مهام، اعتبر الأداء جيد
        ELSE (SUM(CASE WHEN Status = 'Completed' THEN 1 ELSE 0 END) * 100.0) / COUNT(*)
    END
    FROM Projects.Tasks
    WHERE AssignedTo = @EmployeeID 
        AND CreatedDate >= DATEADD(MONTH, -6, GETDATE()); -- آخر 6 أشهر
    
    -- حساب سنوات الخدمة
    SELECT @YearsOfService = DATEDIFF(YEAR, HireDate, GETDATE())
    FROM HR.Employees
    WHERE EmployeeID = @EmployeeID;
    
    -- تحديد مستوى الأداء
    IF @AttendanceRate >= 95 AND @TaskCompletionRate >= 90
        SET @PerformanceLevel = 'ممتاز';
    ELSE IF @AttendanceRate >= 90 AND @TaskCompletionRate >= 80
        SET @PerformanceLevel = 'جيد جداً';
    ELSE IF @AttendanceRate >= 85 AND @TaskCompletionRate >= 70
        SET @PerformanceLevel = 'جيد';
    ELSE IF @AttendanceRate >= 80 AND @TaskCompletionRate >= 60
        SET @PerformanceLevel = 'متوسط';
    ELSE
        SET @PerformanceLevel = 'ضعيف';
    
    RETURN @PerformanceLevel;
END;
GO

-- دالة جدولية لإرجاع تفاصيل الموظفين في قسم معين
CREATE FUNCTION HR.fn_GetDepartmentEmployees(@DepartmentID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        e.EmployeeID,
        e.FirstName + ' ' + e.LastName AS FullName,
        e.Position,
        e.Email,
        e.Salary,
        e.HireDate,
        HR.fn_GetYearsOfService(e.HireDate) AS YearsOfService,
        HR.fn_CalculateAnnualBonus(e.EmployeeID) AS AnnualBonus,
        HR.fn_GetEmployeePerformanceLevel(e.EmployeeID) AS PerformanceLevel
    FROM HR.Employees e
    WHERE e.DepartmentID = @DepartmentID AND e.IsActive = 1
);
GO

-- دالة جدولية لإرجاع المشاريع النشطة مع تفاصيل التقدم
CREATE FUNCTION Projects.fn_GetActiveProjectsWithProgress()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        p.ProjectID,
        p.ProjectName,
        p.ProjectCode,
        p.StartDate,
        p.EndDate,
        p.Budget,
        Projects.fn_GetProjectProgress(p.ProjectID) AS ProgressPercentage,
        Projects.fn_CalculateProjectCost(p.ProjectID) AS EstimatedCost,
        pm.FirstName + ' ' + pm.LastName AS ProjectManagerName,
        DATEDIFF(DAY, p.StartDate, ISNULL(p.EndDate, GETDATE())) AS ProjectDurationDays
    FROM Projects.Projects p
    INNER JOIN HR.Employees pm ON p.ProjectManagerID = pm.EmployeeID
    WHERE p.Status IN ('Planning', 'In Progress')
);
GO

PRINT 'تم إنشاء جميع الدوال بنجاح';

