-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 12_backup_and_security.sql
-- الوصف: إعداد النسخ الاحتياطي والأمان
-- ===================================================

USE CompanyManagementDB;
GO

-- ===================================================
-- 1. إنشاء أدوار الأمان المخصصة
-- ===================================================

-- دور للموارد البشرية
CREATE ROLE HR_Manager;
CREATE ROLE HR_Employee;

-- دور لإدارة المشاريع
CREATE ROLE Project_Manager;
CREATE ROLE Project_Member;

-- دور للمالية
CREATE ROLE Finance_Manager;
CREATE ROLE Finance_Employee;

-- دور للإدارة العليا
CREATE ROLE Executive;

-- دور للقراءة فقط
CREATE ROLE ReadOnly_User;

-- ===================================================
-- 2. تعيين صلاحيات الأدوار
-- ===================================================

-- صلاحيات مدير الموارد البشرية
GRANT SELECT, INSERT, UPDATE ON HR.Employees TO HR_Manager;
GRANT SELECT, INSERT, UPDATE ON HR.Departments TO HR_Manager;
GRANT SELECT, INSERT, UPDATE, DELETE ON HR.Attendance TO HR_Manager;
GRANT SELECT ON Finance.SalaryHistory TO HR_Manager;
GRANT EXECUTE ON HR.sp_AddEmployee TO HR_Manager;
GRANT EXECUTE ON HR.sp_UpdateEmployeeSalary TO HR_Manager;
GRANT EXECUTE ON HR.sp_RecordAttendance TO HR_Manager;
GRANT EXECUTE ON HR.sp_GetEmployeePerformanceReport TO HR_Manager;

-- صلاحيات موظف الموارد البشرية
GRANT SELECT ON HR.Employees TO HR_Employee;
GRANT SELECT ON HR.Departments TO HR_Employee;
GRANT SELECT, INSERT, UPDATE ON HR.Attendance TO HR_Employee;
GRANT EXECUTE ON HR.sp_RecordAttendance TO HR_Employee;

-- صلاحيات مدير المشاريع
GRANT SELECT ON HR.Employees TO Project_Manager;
GRANT SELECT, INSERT, UPDATE ON Projects.Projects TO Project_Manager;
GRANT SELECT, INSERT, UPDATE, DELETE ON Projects.Tasks TO Project_Manager;
GRANT SELECT, INSERT, UPDATE ON Projects.EmployeeProjects TO Project_Manager;
GRANT EXECUTE ON Projects.sp_AddProject TO Project_Manager;
GRANT EXECUTE ON Projects.sp_CompleteProject TO Project_Manager;

-- صلاحيات عضو فريق المشروع
GRANT SELECT ON Projects.Projects TO Project_Member;
GRANT SELECT, UPDATE ON Projects.Tasks TO Project_Member;
GRANT SELECT ON Projects.EmployeeProjects TO Project_Member;

-- صلاحيات مدير المالية
GRANT SELECT ON HR.Employees TO Finance_Manager;
GRANT SELECT, INSERT, UPDATE ON Finance.SalaryHistory TO Finance_Manager;
GRANT EXECUTE ON HR.sp_UpdateEmployeeSalary TO Finance_Manager;

-- صلاحيات موظف المالية
GRANT SELECT ON HR.Employees TO Finance_Employee;
GRANT SELECT ON Finance.SalaryHistory TO Finance_Employee;

-- صلاحيات الإدارة العليا (قراءة جميع البيانات)
GRANT SELECT ON SCHEMA::HR TO Executive;
GRANT SELECT ON SCHEMA::Projects TO Executive;
GRANT SELECT ON SCHEMA::Finance TO Executive;
GRANT SELECT ON dbo.AuditLog TO Executive;

-- صلاحيات القراءة فقط
GRANT SELECT ON HR.vw_EmployeeDetails TO ReadOnly_User;
GRANT SELECT ON HR.vw_DepartmentStatistics TO ReadOnly_User;
GRANT SELECT ON Projects.vw_ProjectDetails TO ReadOnly_User;
GRANT SELECT ON Projects.vw_TaskDetails TO ReadOnly_User;

-- ===================================================
-- 3. إنشاء مستخدمين نموذجيين
-- ===================================================

-- إنشاء مستخدمين على مستوى الخادم (يجب تنفيذها على master database)
/*
USE master;
GO

CREATE LOGIN hr_manager_login WITH PASSWORD = 'HRManager@2024!';
CREATE LOGIN project_manager_login WITH PASSWORD = 'ProjectMgr@2024!';
CREATE LOGIN finance_manager_login WITH PASSWORD = 'FinanceMgr@2024!';
CREATE LOGIN readonly_user_login WITH PASSWORD = 'ReadOnly@2024!';

USE CompanyManagementDB;
GO
*/

-- إنشاء مستخدمين على مستوى قاعدة البيانات
CREATE USER hr_manager_user FOR LOGIN hr_manager_login;
CREATE USER project_manager_user FOR LOGIN project_manager_login;
CREATE USER finance_manager_user FOR LOGIN finance_manager_login;
CREATE USER readonly_user FOR LOGIN readonly_user_login;

-- تعيين الأدوار للمستخدمين
ALTER ROLE HR_Manager ADD MEMBER hr_manager_user;
ALTER ROLE Project_Manager ADD MEMBER project_manager_user;
ALTER ROLE Finance_Manager ADD MEMBER finance_manager_user;
ALTER ROLE ReadOnly_User ADD MEMBER readonly_user;

-- ===================================================
-- 4. إنشاء سياسات الأمان على مستوى الصفوف (RLS)
-- ===================================================

-- تمكين RLS على جدول الموظفين
ALTER TABLE HR.Employees ENABLE ROW LEVEL SECURITY;

-- إنشاء دالة أمان للموظفين
CREATE FUNCTION Security.fn_EmployeeSecurityPredicate(@DepartmentID INT)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN SELECT 1 AS fn_securitypredicate_result
WHERE 
    -- مديرو الموارد البشرية يمكنهم رؤية جميع الموظفين
    IS_MEMBER('HR_Manager') = 1
    OR
    -- الإدارة العليا يمكنها رؤية جميع الموظفين
    IS_MEMBER('Executive') = 1
    OR
    -- الموظفون يمكنهم رؤية موظفي قسمهم فقط
    (IS_MEMBER('HR_Employee') = 1 AND @DepartmentID = (
        SELECT DepartmentID FROM HR.Employees 
        WHERE Email = SYSTEM_USER + '@company.com'
    ));
GO

-- إنشاء سياسة الأمان
CREATE SECURITY POLICY Security.EmployeeSecurityPolicy
ADD FILTER PREDICATE Security.fn_EmployeeSecurityPredicate(DepartmentID) ON HR.Employees
WITH (STATE = ON);

-- ===================================================
-- 5. تشفير البيانات الحساسة
-- ===================================================

-- إنشاء مفتاح رئيسي لقاعدة البيانات
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'CompanyDB@MasterKey2024!';

-- إنشاء شهادة للتشفير
CREATE CERTIFICATE EmployeeDataCert
WITH SUBJECT = 'Employee Sensitive Data Certificate';

-- إنشاء مفتاح متماثل للتشفير
CREATE SYMMETRIC KEY EmployeeDataKey
WITH ALGORITHM = AES_256
ENCRYPTION BY CERTIFICATE EmployeeDataCert;

-- إضافة عمود مشفر للراتب (مثال)
ALTER TABLE HR.Employees ADD EncryptedSalary VARBINARY(256);

-- إجراء لتشفير الرواتب
CREATE PROCEDURE Security.sp_EncryptSalaries
AS
BEGIN
    OPEN SYMMETRIC KEY EmployeeDataKey
    DECRYPTION BY CERTIFICATE EmployeeDataCert;
    
    UPDATE HR.Employees
    SET EncryptedSalary = EncryptByKey(Key_GUID('EmployeeDataKey'), CAST(Salary AS NVARCHAR(20)));
    
    CLOSE SYMMETRIC KEY EmployeeDataKey;
END;
GO

-- إجراء لفك تشفير الرواتب
CREATE FUNCTION Security.fn_DecryptSalary(@EncryptedSalary VARBINARY(256))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @DecryptedSalary DECIMAL(10,2);
    
    OPEN SYMMETRIC KEY EmployeeDataKey
    DECRYPTION BY CERTIFICATE EmployeeDataCert;
    
    SET @DecryptedSalary = CAST(DecryptByKey(@EncryptedSalary) AS DECIMAL(10,2));
    
    CLOSE SYMMETRIC KEY EmployeeDataKey;
    
    RETURN @DecryptedSalary;
END;
GO

-- ===================================================
-- 6. إعداد النسخ الاحتياطي
-- ===================================================

-- إنشاء جهاز النسخ الاحتياطي
EXEC sp_addumpdevice 'disk', 'CompanyDB_Full_Backup',
'C:\Backup\CompanyManagementDB_Full.bak';

EXEC sp_addumpdevice 'disk', 'CompanyDB_Diff_Backup',
'C:\Backup\CompanyManagementDB_Diff.bak';

EXEC sp_addumpdevice 'disk', 'CompanyDB_Log_Backup',
'C:\Backup\CompanyManagementDB_Log.trn';

-- إجراء للنسخ الاحتياطي الكامل
CREATE PROCEDURE dbo.sp_FullBackup
AS
BEGIN
    DECLARE @BackupPath NVARCHAR(500);
    DECLARE @BackupName NVARCHAR(200);
    
    SET @BackupPath = 'C:\Backup\CompanyManagementDB_Full_' + 
                      REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '_') + '.bak';
    SET @BackupName = 'CompanyManagementDB Full Backup - ' + CONVERT(NVARCHAR(20), GETDATE(), 120);
    
    BACKUP DATABASE CompanyManagementDB 
    TO DISK = @BackupPath
    WITH 
        FORMAT,
        INIT,
        NAME = @BackupName,
        COMPRESSION,
        CHECKSUM,
        STATS = 10;
    
    PRINT 'Full backup completed: ' + @BackupPath;
END;
GO

-- إجراء للنسخ الاحتياطي التفاضلي
CREATE PROCEDURE dbo.sp_DifferentialBackup
AS
BEGIN
    DECLARE @BackupPath NVARCHAR(500);
    DECLARE @BackupName NVARCHAR(200);
    
    SET @BackupPath = 'C:\Backup\CompanyManagementDB_Diff_' + 
                      REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '_') + '.bak';
    SET @BackupName = 'CompanyManagementDB Differential Backup - ' + CONVERT(NVARCHAR(20), GETDATE(), 120);
    
    BACKUP DATABASE CompanyManagementDB 
    TO DISK = @BackupPath
    WITH 
        DIFFERENTIAL,
        FORMAT,
        INIT,
        NAME = @BackupName,
        COMPRESSION,
        CHECKSUM,
        STATS = 10;
    
    PRINT 'Differential backup completed: ' + @BackupPath;
END;
GO

-- إجراء لنسخ احتياطي لسجل المعاملات
CREATE PROCEDURE dbo.sp_LogBackup
AS
BEGIN
    DECLARE @BackupPath NVARCHAR(500);
    DECLARE @BackupName NVARCHAR(200);
    
    SET @BackupPath = 'C:\Backup\CompanyManagementDB_Log_' + 
                      REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '_') + '.trn';
    SET @BackupName = 'CompanyManagementDB Log Backup - ' + CONVERT(NVARCHAR(20), GETDATE(), 120);
    
    BACKUP LOG CompanyManagementDB 
    TO DISK = @BackupPath
    WITH 
        FORMAT,
        INIT,
        NAME = @BackupName,
        COMPRESSION,
        CHECKSUM,
        STATS = 10;
    
    PRINT 'Log backup completed: ' + @BackupPath;
END;
GO

-- ===================================================
-- 7. مراقبة الأمان
-- ===================================================

-- جدول لتسجيل محاولات الوصول
CREATE TABLE Security.AccessLog (
    AccessLogID INT IDENTITY(1,1) PRIMARY KEY,
    UserName NVARCHAR(100) NOT NULL,
    LoginTime DATETIME2 DEFAULT GETDATE(),
    IPAddress NVARCHAR(50),
    ApplicationName NVARCHAR(100),
    DatabaseName NVARCHAR(100),
    ObjectAccessed NVARCHAR(200),
    ActionType NVARCHAR(50),
    Success BIT DEFAULT 1
);

-- مشغل لتسجيل الوصول للجداول الحساسة
CREATE TRIGGER Security.tr_LogSensitiveAccess
ON HR.Employees
AFTER SELECT, INSERT, UPDATE, DELETE
AS
BEGIN
    INSERT INTO Security.AccessLog (UserName, DatabaseName, ObjectAccessed, ActionType)
    VALUES (
        SYSTEM_USER,
        DB_NAME(),
        'HR.Employees',
        CASE 
            WHEN EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted) THEN 'UPDATE'
            WHEN EXISTS (SELECT * FROM inserted) THEN 'INSERT'
            WHEN EXISTS (SELECT * FROM deleted) THEN 'DELETE'
            ELSE 'SELECT'
        END
    );
END;
GO

-- مشهد لمراقبة الوصول
CREATE VIEW Security.vw_AccessMonitoring
AS
SELECT 
    UserName,
    COUNT(*) AS AccessCount,
    MAX(LoginTime) AS LastAccess,
    STRING_AGG(DISTINCT ObjectAccessed, ', ') AS ObjectsAccessed,
    STRING_AGG(DISTINCT ActionType, ', ') AS ActionsPerformed
FROM Security.AccessLog
WHERE LoginTime >= DATEADD(DAY, -7, GETDATE())
GROUP BY UserName;
GO

-- ===================================================
-- 8. إجراءات الطوارئ
-- ===================================================

-- إجراء لتعطيل جميع المستخدمين في حالة الطوارئ
CREATE PROCEDURE Security.sp_EmergencyLockdown
    @Reason NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- تسجيل حدث الطوارئ
    INSERT INTO Security.AccessLog (UserName, ObjectAccessed, ActionType, Success)
    VALUES ('SYSTEM', 'EMERGENCY_LOCKDOWN', @Reason, 1);
    
    -- تعطيل جميع المستخدمين ما عدا المديرين
    DECLARE @SQL NVARCHAR(MAX) = '';
    
    SELECT @SQL = @SQL + 'ALTER USER [' + name + '] WITH DEFAULT_SCHEMA = [dbo]; '
    FROM sys.database_principals
    WHERE type = 'S' 
        AND name NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys')
        AND name NOT LIKE '%_manager_%';
    
    IF @SQL != ''
        EXEC sp_executesql @SQL;
    
    PRINT 'Emergency lockdown activated. Reason: ' + @Reason;
END;
GO

-- إجراء لاستعادة الوصول بعد الطوارئ
CREATE PROCEDURE Security.sp_RestoreAccess
AS
BEGIN
    SET NOCOUNT ON;
    
    -- إعادة تفعيل المستخدمين
    -- (يجب تخصيص هذا حسب الحاجة)
    
    INSERT INTO Security.AccessLog (UserName, ObjectAccessed, ActionType, Success)
    VALUES ('SYSTEM', 'ACCESS_RESTORED', 'Normal operations resumed', 1);
    
    PRINT 'Access restored successfully.';
END;
GO

-- ===================================================
-- 9. تدقيق قاعدة البيانات
-- ===================================================

-- تمكين تدقيق قاعدة البيانات (يتطلب صلاحيات خادم)
/*
USE master;
GO

CREATE SERVER AUDIT CompanyDB_Audit
TO FILE (FILEPATH = 'C:\Audit\CompanyDB_Audit.sqlaudit');

ALTER SERVER AUDIT CompanyDB_Audit WITH (STATE = ON);

USE CompanyManagementDB;
GO

CREATE DATABASE AUDIT SPECIFICATION CompanyDB_Database_Audit
FOR SERVER AUDIT CompanyDB_Audit
ADD (SELECT, INSERT, UPDATE, DELETE ON HR.Employees BY PUBLIC),
ADD (SELECT, INSERT, UPDATE, DELETE ON Finance.SalaryHistory BY PUBLIC),
ADD (EXECUTE ON Security.sp_EmergencyLockdown BY PUBLIC);

ALTER DATABASE AUDIT SPECIFICATION CompanyDB_Database_Audit WITH (STATE = ON);
*/

PRINT 'تم إنشاء جميع إعدادات الأمان والنسخ الاحتياطي بنجاح';

