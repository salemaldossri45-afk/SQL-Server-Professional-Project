-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 09_sample_queries.sql
-- الوصف: استعلامات نموذجية لاستخدام قاعدة البيانات
-- ===================================================

USE CompanyManagementDB;
GO

-- ===================================================
-- 1. استعلامات أساسية
-- ===================================================

-- عرض جميع الموظفين مع تفاصيل أقسامهم
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS FullName,
    e.Position,
    e.Email,
    e.Salary,
    d.DepartmentName,
    m.FirstName + ' ' + m.LastName AS ManagerName
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
LEFT JOIN HR.Employees m ON e.ManagerID = m.EmployeeID
WHERE e.IsActive = 1
ORDER BY d.DepartmentName, e.FirstName;

-- عرض المشاريع النشطة مع تفاصيل فرق العمل
SELECT 
    p.ProjectName,
    p.ProjectCode,
    p.Status,
    p.Budget,
    pm.FirstName + ' ' + pm.LastName AS ProjectManager,
    COUNT(ep.EmployeeID) AS TeamSize,
    SUM(ep.HoursAllocated) AS TotalAllocatedHours
FROM Projects.Projects p
INNER JOIN HR.Employees pm ON p.ProjectManagerID = pm.EmployeeID
LEFT JOIN Projects.EmployeeProjects ep ON p.ProjectID = ep.ProjectID AND ep.IsActive = 1
WHERE p.Status IN ('Planning', 'In Progress')
GROUP BY p.ProjectID, p.ProjectName, p.ProjectCode, p.Status, p.Budget,
         pm.FirstName, pm.LastName
ORDER BY p.ProjectName;

-- ===================================================
-- 2. استعلامات إحصائية
-- ===================================================

-- إحصائيات الموظفين حسب القسم
SELECT 
    d.DepartmentName,
    COUNT(e.EmployeeID) AS TotalEmployees,
    AVG(e.Salary) AS AverageSalary,
    MIN(e.Salary) AS MinSalary,
    MAX(e.Salary) AS MaxSalary,
    SUM(e.Salary) AS TotalSalaryBudget
FROM HR.Departments d
LEFT JOIN HR.Employees e ON d.DepartmentID = e.DepartmentID AND e.IsActive = 1
GROUP BY d.DepartmentID, d.DepartmentName
ORDER BY TotalEmployees DESC;

-- إحصائيات المشاريع حسب الحالة
SELECT 
    Status,
    COUNT(*) AS ProjectCount,
    AVG(Budget) AS AverageBudget,
    SUM(Budget) AS TotalBudget,
    AVG(DATEDIFF(DAY, StartDate, ISNULL(EndDate, GETDATE()))) AS AverageDurationDays
FROM Projects.Projects
GROUP BY Status
ORDER BY ProjectCount DESC;

-- ===================================================
-- 3. استعلامات متقدمة مع Window Functions
-- ===================================================

-- ترتيب الموظفين حسب الراتب داخل كل قسم
SELECT 
    e.FirstName + ' ' + e.LastName AS FullName,
    d.DepartmentName,
    e.Salary,
    RANK() OVER (PARTITION BY d.DepartmentID ORDER BY e.Salary DESC) AS SalaryRank,
    DENSE_RANK() OVER (PARTITION BY d.DepartmentID ORDER BY e.Salary DESC) AS SalaryDenseRank,
    ROW_NUMBER() OVER (PARTITION BY d.DepartmentID ORDER BY e.Salary DESC) AS RowNumber
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
WHERE e.IsActive = 1
ORDER BY d.DepartmentName, e.Salary DESC;

-- حساب المتوسط المتحرك للرواتب
SELECT 
    e.FirstName + ' ' + e.LastName AS FullName,
    e.Salary,
    AVG(e.Salary) OVER (ORDER BY e.EmployeeID ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS MovingAverage,
    LAG(e.Salary, 1) OVER (ORDER BY e.EmployeeID) AS PreviousSalary,
    LEAD(e.Salary, 1) OVER (ORDER BY e.EmployeeID) AS NextSalary
FROM HR.Employees e
WHERE e.IsActive = 1
ORDER BY e.EmployeeID;

-- ===================================================
-- 4. استعلامات CTE (Common Table Expressions)
-- ===================================================

-- الهيكل التنظيمي للشركة (Recursive CTE)
WITH EmployeeHierarchy AS (
    -- المديرين العامين (بدون مدير مباشر)
    SELECT 
        EmployeeID,
        FirstName + ' ' + LastName AS FullName,
        Position,
        ManagerID,
        0 AS Level,
        CAST(FirstName + ' ' + LastName AS NVARCHAR(1000)) AS HierarchyPath
    FROM HR.Employees
    WHERE ManagerID IS NULL AND IsActive = 1
    
    UNION ALL
    
    -- الموظفين تحت الإدارة
    SELECT 
        e.EmployeeID,
        e.FirstName + ' ' + e.LastName,
        e.Position,
        e.ManagerID,
        eh.Level + 1,
        CAST(eh.HierarchyPath + ' -> ' + e.FirstName + ' ' + e.LastName AS NVARCHAR(1000))
    FROM HR.Employees e
    INNER JOIN EmployeeHierarchy eh ON e.ManagerID = eh.EmployeeID
    WHERE e.IsActive = 1
)
SELECT 
    EmployeeID,
    REPLICATE('  ', Level) + FullName AS HierarchicalName,
    Position,
    Level,
    HierarchyPath
FROM EmployeeHierarchy
ORDER BY HierarchyPath;

-- تحليل أداء المشاريع
WITH ProjectPerformance AS (
    SELECT 
        p.ProjectID,
        p.ProjectName,
        p.Budget,
        COUNT(t.TaskID) AS TotalTasks,
        COUNT(CASE WHEN t.Status = 'Completed' THEN 1 END) AS CompletedTasks,
        SUM(t.EstimatedHours) AS TotalEstimatedHours,
        SUM(t.ActualHours) AS TotalActualHours
    FROM Projects.Projects p
    LEFT JOIN Projects.Tasks t ON p.ProjectID = t.ProjectID
    GROUP BY p.ProjectID, p.ProjectName, p.Budget
)
SELECT 
    ProjectName,
    Budget,
    TotalTasks,
    CompletedTasks,
    CASE 
        WHEN TotalTasks = 0 THEN 0
        ELSE CAST(CompletedTasks * 100.0 / TotalTasks AS DECIMAL(5,2))
    END AS CompletionPercentage,
    TotalEstimatedHours,
    TotalActualHours,
    CASE 
        WHEN TotalEstimatedHours = 0 THEN 0
        ELSE CAST((TotalActualHours - TotalEstimatedHours) * 100.0 / TotalEstimatedHours AS DECIMAL(5,2))
    END AS HoursVariancePercentage
FROM ProjectPerformance
ORDER BY CompletionPercentage DESC;

-- ===================================================
-- 5. استعلامات تحليلية معقدة
-- ===================================================

-- تحليل الحضور الشهري مع المقارنات
SELECT 
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    d.DepartmentName,
    YEAR(a.AttendanceDate) AS Year,
    MONTH(a.AttendanceDate) AS Month,
    COUNT(*) AS WorkingDays,
    SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) AS PresentDays,
    CAST(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS AttendanceRate,
    AVG(a.WorkingHours) AS AvgDailyHours,
    LAG(CAST(SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)), 1) 
        OVER (PARTITION BY e.EmployeeID ORDER BY YEAR(a.AttendanceDate), MONTH(a.AttendanceDate)) AS PreviousMonthRate
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
INNER JOIN HR.Attendance a ON e.EmployeeID = a.EmployeeID
WHERE e.IsActive = 1
GROUP BY e.EmployeeID, e.FirstName, e.LastName, d.DepartmentName,
         YEAR(a.AttendanceDate), MONTH(a.AttendanceDate)
ORDER BY e.FirstName, Year, Month;

-- تحليل توزيع المهام حسب الأولوية والحالة
SELECT 
    Priority,
    Status,
    COUNT(*) AS TaskCount,
    AVG(EstimatedHours) AS AvgEstimatedHours,
    AVG(ActualHours) AS AvgActualHours,
    COUNT(*) * 100.0 / SUM(COUNT(*)) OVER() AS PercentageOfTotal
FROM Projects.Tasks
GROUP BY Priority, Status
ORDER BY 
    CASE Priority 
        WHEN 'Critical' THEN 1 
        WHEN 'High' THEN 2 
        WHEN 'Medium' THEN 3 
        WHEN 'Low' THEN 4 
    END,
    CASE Status 
        WHEN 'Completed' THEN 1 
        WHEN 'In Progress' THEN 2 
        WHEN 'On Hold' THEN 3 
        WHEN 'Not Started' THEN 4 
    END;

-- ===================================================
-- 6. استعلامات باستخدام الدوال المخصصة
-- ===================================================

-- تقرير شامل عن أداء الموظفين
SELECT 
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS FullName,
    e.Position,
    d.DepartmentName,
    e.Salary,
    HR.fn_GetYearsOfService(e.HireDate) AS YearsOfService,
    HR.fn_CalculateAnnualBonus(e.EmployeeID) AS AnnualBonus,
    HR.fn_GetAttendanceRate(e.EmployeeID, DATEADD(MONTH, -3, GETDATE()), GETDATE()) AS AttendanceRate3Months,
    HR.fn_GetEmployeePerformanceLevel(e.EmployeeID) AS PerformanceLevel
FROM HR.Employees e
INNER JOIN HR.Departments d ON e.DepartmentID = d.DepartmentID
WHERE e.IsActive = 1
ORDER BY HR.fn_GetEmployeePerformanceLevel(e.EmployeeID), e.FirstName;

-- تقرير المشاريع مع التقدم والتكلفة
SELECT 
    p.ProjectName,
    p.Budget,
    Projects.fn_GetProjectProgress(p.ProjectID) AS ProgressPercentage,
    Projects.fn_CalculateProjectCost(p.ProjectID) AS EstimatedCost,
    p.Budget - Projects.fn_CalculateProjectCost(p.ProjectID) AS BudgetVariance,
    pm.FirstName + ' ' + pm.LastName AS ProjectManager
FROM Projects.Projects p
INNER JOIN HR.Employees pm ON p.ProjectManagerID = pm.EmployeeID
WHERE p.Status IN ('Planning', 'In Progress')
ORDER BY ProgressPercentage DESC;

-- ===================================================
-- 7. استعلامات باستخدام المشاهد
-- ===================================================

-- استخدام مشهد تفاصيل الموظفين
SELECT * FROM HR.vw_EmployeeDetails
WHERE DepartmentName = 'تقنية المعلومات'
ORDER BY YearsOfService DESC;

-- استخدام مشهد إحصائيات الأقسام
SELECT * FROM HR.vw_DepartmentStatistics
ORDER BY TotalEmployees DESC;

-- استخدام مشهد تفاصيل المشاريع
SELECT * FROM Projects.vw_ProjectDetails
WHERE Status = 'In Progress'
ORDER BY TotalAllocatedHours DESC;

PRINT 'تم تنفيذ جميع الاستعلامات النموذجية بنجاح';

