-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 02_create_tables.sql
-- الوصف: إنشاء جميع الجداول والعلاقات
-- ===================================================

USE CompanyManagementDB;
GO

-- جدول الأقسام
CREATE TABLE HR.Departments (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    DepartmentName NVARCHAR(100) NOT NULL UNIQUE,
    DepartmentCode NVARCHAR(10) NOT NULL UNIQUE,
    ManagerID INT NULL,
    Budget DECIMAL(15,2) DEFAULT 0,
    CreatedDate DATETIME2 DEFAULT GETDATE(),
    IsActive BIT DEFAULT 1
);

-- جدول الموظفين
CREATE TABLE HR.Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Phone NVARCHAR(20),
    HireDate DATE NOT NULL,
    DepartmentID INT NOT NULL,
    Position NVARCHAR(100) NOT NULL,
    Salary DECIMAL(10,2) NOT NULL CHECK (Salary > 0),
    ManagerID INT NULL,
    IsActive BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT GETDATE(),
    ModifiedDate DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT FK_Employees_Department 
        FOREIGN KEY (DepartmentID) REFERENCES HR.Departments(DepartmentID),
    CONSTRAINT FK_Employees_Manager 
        FOREIGN KEY (ManagerID) REFERENCES HR.Employees(EmployeeID)
);

-- إضافة المدير للقسم بعد إنشاء جدول الموظفين
ALTER TABLE HR.Departments
ADD CONSTRAINT FK_Departments_Manager 
    FOREIGN KEY (ManagerID) REFERENCES HR.Employees(EmployeeID);

-- جدول المشاريع
CREATE TABLE Projects.Projects (
    ProjectID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectName NVARCHAR(200) NOT NULL,
    ProjectCode NVARCHAR(20) NOT NULL UNIQUE,
    Description NVARCHAR(MAX),
    StartDate DATE NOT NULL,
    EndDate DATE,
    Budget DECIMAL(15,2) NOT NULL CHECK (Budget > 0),
    Status NVARCHAR(20) DEFAULT 'Planning' 
        CHECK (Status IN ('Planning', 'In Progress', 'Completed', 'On Hold', 'Cancelled')),
    ProjectManagerID INT NOT NULL,
    CreatedDate DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT FK_Projects_Manager 
        FOREIGN KEY (ProjectManagerID) REFERENCES HR.Employees(EmployeeID),
    CONSTRAINT CHK_Projects_Dates 
        CHECK (EndDate IS NULL OR EndDate >= StartDate)
);

-- جدول ربط الموظفين بالمشاريع (Many-to-Many)
CREATE TABLE Projects.EmployeeProjects (
    EmployeeProjectID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    ProjectID INT NOT NULL,
    Role NVARCHAR(100) NOT NULL,
    AssignedDate DATE DEFAULT GETDATE(),
    HoursAllocated DECIMAL(5,2) DEFAULT 0,
    IsActive BIT DEFAULT 1,
    
    CONSTRAINT FK_EmployeeProjects_Employee 
        FOREIGN KEY (EmployeeID) REFERENCES HR.Employees(EmployeeID),
    CONSTRAINT FK_EmployeeProjects_Project 
        FOREIGN KEY (ProjectID) REFERENCES Projects.Projects(ProjectID),
    CONSTRAINT UQ_EmployeeProjects 
        UNIQUE (EmployeeID, ProjectID, Role)
);

-- جدول تاريخ الرواتب
CREATE TABLE Finance.SalaryHistory (
    SalaryHistoryID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    OldSalary DECIMAL(10,2) NOT NULL,
    NewSalary DECIMAL(10,2) NOT NULL,
    ChangeDate DATE DEFAULT GETDATE(),
    ChangeReason NVARCHAR(200),
    ApprovedBy INT,
    
    CONSTRAINT FK_SalaryHistory_Employee 
        FOREIGN KEY (EmployeeID) REFERENCES HR.Employees(EmployeeID),
    CONSTRAINT FK_SalaryHistory_ApprovedBy 
        FOREIGN KEY (ApprovedBy) REFERENCES HR.Employees(EmployeeID)
);

-- جدول الحضور
CREATE TABLE HR.Attendance (
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    CheckInTime TIME,
    CheckOutTime TIME,
    WorkingHours AS (
        CASE 
            WHEN CheckInTime IS NOT NULL AND CheckOutTime IS NOT NULL 
            THEN DATEDIFF(MINUTE, CheckInTime, CheckOutTime) / 60.0
            ELSE 0
        END
    ) PERSISTED,
    Status NVARCHAR(20) DEFAULT 'Present' 
        CHECK (Status IN ('Present', 'Absent', 'Late', 'Half Day', 'Sick Leave', 'Vacation')),
    Notes NVARCHAR(500),
    
    CONSTRAINT FK_Attendance_Employee 
        FOREIGN KEY (EmployeeID) REFERENCES HR.Employees(EmployeeID),
    CONSTRAINT UQ_Attendance_EmployeeDate 
        UNIQUE (EmployeeID, AttendanceDate)
);

-- جدول المهام
CREATE TABLE Projects.Tasks (
    TaskID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID INT NOT NULL,
    TaskName NVARCHAR(200) NOT NULL,
    Description NVARCHAR(MAX),
    AssignedTo INT NOT NULL,
    Priority NVARCHAR(10) DEFAULT 'Medium' 
        CHECK (Priority IN ('Low', 'Medium', 'High', 'Critical')),
    Status NVARCHAR(20) DEFAULT 'Not Started' 
        CHECK (Status IN ('Not Started', 'In Progress', 'Completed', 'On Hold')),
    EstimatedHours DECIMAL(5,2),
    ActualHours DECIMAL(5,2) DEFAULT 0,
    StartDate DATE,
    DueDate DATE,
    CompletedDate DATE,
    CreatedDate DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT FK_Tasks_Project 
        FOREIGN KEY (ProjectID) REFERENCES Projects.Projects(ProjectID),
    CONSTRAINT FK_Tasks_AssignedTo 
        FOREIGN KEY (AssignedTo) REFERENCES HR.Employees(EmployeeID),
    CONSTRAINT CHK_Tasks_Dates 
        CHECK (DueDate IS NULL OR StartDate IS NULL OR DueDate >= StartDate)
);

PRINT 'تم إنشاء جميع الجداول بنجاح';

