-- ===================================================
-- مشروع SQL Server احترافي
-- الملف: 08_create_triggers.sql
-- الوصف: إنشاء المشغلات (Triggers) للتحقق من صحة البيانات
-- ===================================================

USE CompanyManagementDB;
GO

-- إنشاء جدول لتسجيل التغييرات (Audit Log)
CREATE TABLE dbo.AuditLog (
    AuditID INT IDENTITY(1,1) PRIMARY KEY,
    TableName NVARCHAR(100) NOT NULL,
    Operation NVARCHAR(10) NOT NULL, -- INSERT, UPDATE, DELETE
    RecordID INT NOT NULL,
    OldValues NVARCHAR(MAX),
    NewValues NVARCHAR(MAX),
    ChangedBy NVARCHAR(100) DEFAULT SYSTEM_USER,
    ChangeDate DATETIME2 DEFAULT GETDATE()
);
GO

-- مشغل لتحديث تاريخ التعديل عند تحديث بيانات الموظف
CREATE TRIGGER HR.tr_Employees_UpdateModifiedDate
ON HR.Employees
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    UPDATE HR.Employees 
    SET ModifiedDate = GETDATE()
    FROM HR.Employees e
    INNER JOIN inserted i ON e.EmployeeID = i.EmployeeID;
END;
GO

-- مشغل لتسجيل التغييرات في جدول الموظفين
CREATE TRIGGER HR.tr_Employees_AuditLog
ON HR.Employees
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Operation NVARCHAR(10);
    
    -- تحديد نوع العملية
    IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
        SET @Operation = 'UPDATE';
    ELSE IF EXISTS (SELECT * FROM inserted)
        SET @Operation = 'INSERT';
    ELSE
        SET @Operation = 'DELETE';
    
    -- تسجيل عمليات الإدراج
    IF @Operation = 'INSERT'
    BEGIN
        INSERT INTO dbo.AuditLog (TableName, Operation, RecordID, NewValues)
        SELECT 
            'HR.Employees',
            'INSERT',
            i.EmployeeID,
            CONCAT('FirstName: ', i.FirstName, ', LastName: ', i.LastName, 
                   ', Email: ', i.Email, ', Position: ', i.Position, 
                   ', Salary: ', i.Salary, ', DepartmentID: ', i.DepartmentID)
        FROM inserted i;
    END
    
    -- تسجيل عمليات التحديث
    IF @Operation = 'UPDATE'
    BEGIN
        INSERT INTO dbo.AuditLog (TableName, Operation, RecordID, OldValues, NewValues)
        SELECT 
            'HR.Employees',
            'UPDATE',
            i.EmployeeID,
            CONCAT('FirstName: ', d.FirstName, ', LastName: ', d.LastName, 
                   ', Email: ', d.Email, ', Position: ', d.Position, 
                   ', Salary: ', d.Salary, ', DepartmentID: ', d.DepartmentID),
            CONCAT('FirstName: ', i.FirstName, ', LastName: ', i.LastName, 
                   ', Email: ', i.Email, ', Position: ', i.Position, 
                   ', Salary: ', i.Salary, ', DepartmentID: ', i.DepartmentID)
        FROM inserted i
        INNER JOIN deleted d ON i.EmployeeID = d.EmployeeID;
    END
    
    -- تسجيل عمليات الحذف
    IF @Operation = 'DELETE'
    BEGIN
        INSERT INTO dbo.AuditLog (TableName, Operation, RecordID, OldValues)
        SELECT 
            'HR.Employees',
            'DELETE',
            d.EmployeeID,
            CONCAT('FirstName: ', d.FirstName, ', LastName: ', d.LastName, 
                   ', Email: ', d.Email, ', Position: ', d.Position, 
                   ', Salary: ', d.Salary, ', DepartmentID: ', d.DepartmentID)
        FROM deleted d;
    END
END;
GO

-- مشغل للتحقق من صحة البيانات عند إدراج أو تحديث الموظفين
CREATE TRIGGER HR.tr_Employees_ValidateData
ON HR.Employees
INSTEAD OF INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- التحقق من صحة البريد الإلكتروني
    IF EXISTS (SELECT 1 FROM inserted WHERE Email NOT LIKE '%@%.%')
    BEGIN
        RAISERROR('البريد الإلكتروني غير صحيح', 16, 1);
        RETURN;
    END
    
    -- التحقق من أن الراتب أكبر من الصفر
    IF EXISTS (SELECT 1 FROM inserted WHERE Salary <= 0)
    BEGIN
        RAISERROR('الراتب يجب أن يكون أكبر من الصفر', 16, 1);
        RETURN;
    END
    
    -- التحقق من أن تاريخ التوظيف ليس في المستقبل
    IF EXISTS (SELECT 1 FROM inserted WHERE HireDate > GETDATE())
    BEGIN
        RAISERROR('تاريخ التوظيف لا يمكن أن يكون في المستقبل', 16, 1);
        RETURN;
    END
    
    -- تنفيذ العملية إذا كانت البيانات صحيحة
    IF EXISTS (SELECT * FROM inserted) AND EXISTS (SELECT * FROM deleted)
    BEGIN
        -- عملية تحديث
        UPDATE e SET 
            FirstName = i.FirstName,
            LastName = i.LastName,
            Email = i.Email,
            Phone = i.Phone,
            HireDate = i.HireDate,
            DepartmentID = i.DepartmentID,
            Position = i.Position,
            Salary = i.Salary,
            ManagerID = i.ManagerID,
            IsActive = i.IsActive,
            ModifiedDate = GETDATE()
        FROM HR.Employees e
        INNER JOIN inserted i ON e.EmployeeID = i.EmployeeID;
    END
    ELSE IF EXISTS (SELECT * FROM inserted)
    BEGIN
        -- عملية إدراج
        INSERT INTO HR.Employees (FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary, ManagerID, IsActive)
        SELECT FirstName, LastName, Email, Phone, HireDate, DepartmentID, Position, Salary, ManagerID, ISNULL(IsActive, 1)
        FROM inserted;
    END
END;
GO

-- مشغل لمنع حذف الأقسام التي تحتوي على موظفين
CREATE TRIGGER HR.tr_Departments_PreventDelete
ON HR.Departments
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- التحقق من وجود موظفين في الأقسام المراد حذفها
    IF EXISTS (
        SELECT 1 
        FROM deleted d
        INNER JOIN HR.Employees e ON d.DepartmentID = e.DepartmentID
        WHERE e.IsActive = 1
    )
    BEGIN
        RAISERROR('لا يمكن حذف قسم يحتوي على موظفين نشطين', 16, 1);
        RETURN;
    END
    
    -- حذف الأقسام التي لا تحتوي على موظفين
    DELETE FROM HR.Departments 
    WHERE DepartmentID IN (SELECT DepartmentID FROM deleted);
END;
GO

-- مشغل لتحديث حالة المشروع تلقائياً عند اكتمال جميع المهام
CREATE TRIGGER Projects.tr_Tasks_UpdateProjectStatus
ON Projects.Tasks
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- التحقق من المشاريع التي تم تحديث مهامها
    DECLARE @ProjectID INT;
    DECLARE project_cursor CURSOR FOR
        SELECT DISTINCT ProjectID FROM inserted;
    
    OPEN project_cursor;
    FETCH NEXT FROM project_cursor INTO @ProjectID;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        DECLARE @TotalTasks INT;
        DECLARE @CompletedTasks INT;
        
        -- حساب عدد المهام الإجمالي والمكتمل
        SELECT 
            @TotalTasks = COUNT(*),
            @CompletedTasks = SUM(CASE WHEN Status = 'Completed' THEN 1 ELSE 0 END)
        FROM Projects.Tasks
        WHERE ProjectID = @ProjectID;
        
        -- تحديث حالة المشروع إذا اكتملت جميع المهام
        IF @TotalTasks > 0 AND @CompletedTasks = @TotalTasks
        BEGIN
            UPDATE Projects.Projects 
            SET Status = 'Completed',
                EndDate = CASE WHEN EndDate IS NULL THEN CAST(GETDATE() AS DATE) ELSE EndDate END
            WHERE ProjectID = @ProjectID AND Status != 'Completed';
        END
        
        FETCH NEXT FROM project_cursor INTO @ProjectID;
    END
    
    CLOSE project_cursor;
    DEALLOCATE project_cursor;
END;
GO

-- مشغل لمنع تعديل المشاريع المكتملة
CREATE TRIGGER Projects.tr_Projects_PreventCompletedModification
ON Projects.Projects
INSTEAD OF UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- التحقق من محاولة تعديل مشاريع مكتملة
    IF EXISTS (
        SELECT 1 
        FROM deleted d
        INNER JOIN inserted i ON d.ProjectID = i.ProjectID
        WHERE d.Status = 'Completed' 
            AND (d.ProjectName != i.ProjectName OR d.Budget != i.Budget OR d.StartDate != i.StartDate)
    )
    BEGIN
        RAISERROR('لا يمكن تعديل تفاصيل المشاريع المكتملة', 16, 1);
        RETURN;
    END
    
    -- السماح بالتحديث للمشاريع غير المكتملة أو التحديثات المسموحة
    UPDATE p SET 
        ProjectName = i.ProjectName,
        ProjectCode = i.ProjectCode,
        Description = i.Description,
        StartDate = i.StartDate,
        EndDate = i.EndDate,
        Budget = i.Budget,
        Status = i.Status,
        ProjectManagerID = i.ProjectManagerID
    FROM Projects.Projects p
    INNER JOIN inserted i ON p.ProjectID = i.ProjectID
    INNER JOIN deleted d ON p.ProjectID = d.ProjectID
    WHERE d.Status != 'Completed' OR i.Status = 'Completed';
END;
GO

-- مشغل لحساب ساعات العمل تلقائياً عند تسجيل الحضور
CREATE TRIGGER HR.tr_Attendance_CalculateWorkingHours
ON HR.Attendance
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- لا حاجة لحساب ساعات العمل يدوياً لأنها محسوبة تلقائياً كـ Computed Column
    -- لكن يمكن إضافة تحققات إضافية هنا
    
    -- التحقق من منطقية أوقات الدخول والخروج
    IF EXISTS (
        SELECT 1 FROM inserted 
        WHERE CheckInTime IS NOT NULL 
            AND CheckOutTime IS NOT NULL 
            AND CheckOutTime <= CheckInTime
    )
    BEGIN
        RAISERROR('وقت الخروج يجب أن يكون بعد وقت الدخول', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
    
    -- التحقق من عدم تجاوز 12 ساعة عمل في اليوم
    IF EXISTS (
        SELECT 1 FROM inserted 
        WHERE CheckInTime IS NOT NULL 
            AND CheckOutTime IS NOT NULL 
            AND DATEDIFF(HOUR, CheckInTime, CheckOutTime) > 12
    )
    BEGIN
        RAISERROR('لا يمكن أن تتجاوز ساعات العمل 12 ساعة في اليوم', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
END;
GO

PRINT 'تم إنشاء جميع المشغلات بنجاح';

